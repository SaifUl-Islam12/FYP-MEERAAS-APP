package com.jbeans.model;

import com.jbeans.meeraas.DATA;
import com.jbeans.meeraas.R;

import java.io.Serializable;

public class Brother extends Heir{

    public Brother(String name) {
        super(name);this.partsIfAsaba = 2;

       if (DATA.getInstance().factor_value==99){
           setNameId(R.string.fb);
        }
        else if (DATA.getInstance().factor_value==111){
           setNameId(R.string.u_fb);
        }
    }

    public double calculateProportion(Wealth deadPerson, double totalParts) {
        if (deadPerson.countHeirByRelation(SON) == 0 && deadPerson.countHeirByRelation(GRAND_SON) == 0
                && deadPerson.getHeir(FATHER) == null && deadPerson.getHeir(PATERNAL_GRAND_FATHER) == null) {
            deadPerson.setTotalPartsForAsabaat(deadPerson.getTotalPartsForAsabaat() + this.getCount() * 2);
            deadPerson.getAsabaat().add(this);
            setAsaba(true);
            setConditionId(R.string.asaba_reason_no_child_no_parent);
            return 0.0;
        }

        // Check the reason for being mahjoob
        if (deadPerson.countHeirByRelation(SON) != 0) {
            setConditionId(R.string.mahjoob_reason_son);
        } else if (deadPerson.countHeirByRelation(GRAND_SON) != 0) {
            setConditionId(R.string.mahjoob_reason_gs);
        } else if (deadPerson.getHeir(FATHER) != null) {
            setConditionId(R.string.mahjoob_reason_father);
        } else if (deadPerson.getHeir(PATERNAL_GRAND_FATHER) != null) {
            setConditionId(R.string.mahjoob_reason_pgf);
        }

        return 0;
    }

    @Override
    public String toString() {
        // TODO Auto-generated method stub
        return "Real Brother : " + getProportion() + (isAsaba() ? " + Asaba" : "" + getCondition());
    }

}

