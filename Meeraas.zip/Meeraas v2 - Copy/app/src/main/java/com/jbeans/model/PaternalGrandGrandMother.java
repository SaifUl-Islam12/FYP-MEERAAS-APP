package com.jbeans.model;

import com.jbeans.meeraas.DATA;
import com.jbeans.meeraas.R;

public class PaternalGrandGrandMother extends PaternalGrandMother {

	public PaternalGrandGrandMother(String name) {
		super(name);

		if (DATA.getInstance().factor_value==99){
			setNameId(R.string.pggm);;
		}
		else if (DATA.getInstance().factor_value==111){
			setNameId(R.string.u_pggm);
		}
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public double calculateProportion(Wealth deadPerson, double totalParts) {
		
		if(deadPerson.getHeir(PATERNAL_GRAND_MOTHER) != null){
			//setCondition(" Mahjoob because of Paternal Grand MOTHER ");
			return 0.0;
		}
		
		if(deadPerson.getHeir(MATERNAL_GRAND_MOTHER) != null){
			//setCondition(" Mahjoob because of Maternal Grand Mother ");
		}
		
		return super.calculateProportion(deadPerson, totalParts);
	}

}
