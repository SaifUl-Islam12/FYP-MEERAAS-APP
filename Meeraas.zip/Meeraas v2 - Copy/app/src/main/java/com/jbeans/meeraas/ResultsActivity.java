package com.jbeans.meeraas;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.widget.ExpandableListView;

import com.jbeans.custom.ExpandableListAdapter;
import com.jbeans.custom.ParceableWealth;
import com.jbeans.model.Heir;
import com.jbeans.model.Wealth;

public class ResultsActivity extends Activity {
    private Wealth wealth;
    private double totalParts = 24;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_results);
        ParceableWealth pWealth = getIntent().getParcelableExtra("wealth");
        this.wealth = pWealth.getWealth();
        // this method finds the proportion of each heir from 24
        this.wealth.distributeAmongHeirs(totalParts);
        // this method distributes among the asabaat
 //       this.wealth.solveAsabaat(totalParts);
        // this method finds the proportion in the wealth left by the deceased
        calculateWealthProportion(this.wealth, totalParts);
        outputResults();
    }

    private void calculateWealthProportion(Wealth wealth, double totalParts) {
        double partsDistributed = 0;
        for (Heir heir : wealth.getHeirs().values()) {
            partsDistributed += heir.getProportion();
        }

        if(partsDistributed >= totalParts)
            totalParts = partsDistributed;
        else
            if(wealth.getAsabaat().size() == 0)
                totalParts = partsDistributed;

        /*if(wealth.getAsabaat().size() == 0) {
            for (Heir heir : wealth.getHeirs().values()) {
                if (heir.getName().equals(Heir.HUSBAND) || heir.getName().equals(Heir.WIFE)) {
                    if (wealth.getHeirs().size() == 1) {
                        heir.setProportion(wealth.getWealth());
                        return;
                    }

                    heir.setProportion(heir.getProportion() / totalParts * wealth.getWealth());
                    wealth.setWealth(wealth.getWealth() - heir.getProportion());
                } else {
                    //partsDistributed += heir.getProportion();
                }
            }

            for (Heir heir : wealth.getHeirs().values()) {
                if (heir.getName().equals(Heir.WIFE) || heir.getName().equals(Heir.HUSBAND))
                    continue;
                heir.setProportion(heir.getProportion() / totalParts * wealth.getWealth());
            }
        }else{
            double remainingWealth = wealth.getWealth();
            for (Heir heir : wealth.getHeirs().values()) {
                heir.setProportion(heir.getProportion() / totalParts * wealth.getWealth());
                remainingWealth -= heir.getProportion();
            }
            distributeAmongAsabaat(wealth, remainingWealth);
        }*/

        // new code
        double remainingWealth = wealth.getWealth();
        for (Heir heir : wealth.getHeirs().values()) {
            heir.setProportion(heir.getProportion() / totalParts * wealth.getWealth());
            remainingWealth -= heir.getProportion();
        }

        if(remainingWealth > 0)
            distributeAmongAsabaat(wealth, remainingWealth);
    }

    private void distributeAmongAsabaat(Wealth wealth, double remainingWealth){
        double totalPartsForAsabaat = 0;
        for(Heir heir:wealth.getAsabaat()){
            totalPartsForAsabaat += heir.getPartsIfAsaba();
        }

        for(Heir heir:wealth.getAsabaat()){
            heir.setProportion(heir.getProportion() + heir.getPartsIfAsaba()/totalPartsForAsabaat*remainingWealth);
        }
    }

    private void outputResults(){
        ExpandableListView elv = (ExpandableListView) findViewById(R.id.eListView);
        elv.setAdapter(new ExpandableListAdapter(wealth,getLayoutInflater(), getResources()));
    }
}
