package com.jbeans.meeraas;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import com.jbeans.custom.ParceableWealth;
import com.jbeans.model.Wealth;

public class WealthInput extends Activity {
    private Wealth wealth;
    EditText tftestement,tfburial_expences;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wealth_input);
        ParceableWealth pWealth = getIntent().getParcelableExtra("wealth");
        this.wealth = pWealth.getWealth();
        tftestement=(EditText)findViewById(R.id.tftestement);
        tfburial_expences=(EditText)findViewById(R.id.tfburial_expences);
    }

    public void onGoClick(View view){
        EditText tfWealth = findViewById(R.id.tfWealth);
        String num = tfburial_expences.getText().toString();
        double tfburial = Double.parseDouble(num);
        String num1 = tftestement.getText().toString();
       Double tfts = Double.parseDouble(num1);
        if(tfWealth.getText().length()>0){
            double wealth = Double.parseDouble(tfWealth.getText().toString())-tfburial-tfts;
            if(wealth >0){
                this.wealth.setWealth(wealth);
                goToResultsPage();
            }
        }
    }

    public void goToResultsPage(){
        Intent intent = new Intent(getApplicationContext(), ResultsActivity.class);
        ParceableWealth pWealth = new ParceableWealth(this.wealth);
        intent.putExtra("wealth", pWealth);
        startActivity(intent);
    }
}
