package com.jbeans.model;

import com.jbeans.meeraas.DATA;
import com.jbeans.meeraas.R;

public class PaternalHalfSister extends Heir {

    public PaternalHalfSister(String name) {
        super(name);
        this.partsIfAsaba = 1;

        if (DATA.getInstance().factor_value==99){
            setNameId(R.string.phs);
        }
        else if (DATA.getInstance().factor_value==111){
            setNameId(R.string.u_phs);;
        }
    }

    @Override
    double calculateProportion(Wealth deadPerson, double totalParts) {
        if (deadPerson.countHeirByRelation(SON) != 0) {
            setCondition("mahjoob_reason_son");
            return 0;
        }
        if (deadPerson.countHeirByRelation(GRAND_SON) != 0) {
            setCondition("mahjoob_reason_grandSon");
            return 0;
        }
        if (deadPerson.getHeir(FATHER) != null) {
            setCondition("mahjoob_reason_father");
            return 0;
        }
        if(deadPerson.countHeirByRelation(REAL_BROTHER) > 0){
            setCondition("mahjoob_reason_fullBrother");
            return 0;
        }
                // condition 4: jab beti ya poti mojood ho aur aini bhai,
        // baap, daada aur aulaad main se koi na ho
        if ((deadPerson.countHeirByRelation(DAUGHTER) > 0 || deadPerson.countHeirByRelation(GRAND_DAUGHTER) > 0)
                && deadPerson.countHeirByRelation(PATERNAL_HALF_BROTHER) == 0
                && deadPerson.countHeirByRelation(REAL_BROTHER) == 0 && deadPerson.countHeirByRelation(SON) == 0
                && deadPerson.countHeirByRelation(GRAND_SON) == 0 && deadPerson.getHeir(FATHER) == null
                && deadPerson.getHeir(PATERNAL_GRAND_FATHER) == null) {
            deadPerson.getAsabaat().add(this);
            setAsaba(true);
            return 0;
        }

		// condition 5: jab allati bhai mojood ho aur aini bhai, aini
        // behnai,baap, daada aur aulaad main se koi na ho
        if (deadPerson.countHeirByRelation(PATERNAL_HALF_BROTHER) > 0 && deadPerson.countHeirByRelation(REAL_BROTHER) == 0
                && deadPerson.countHeirByRelation(REAL_SISTER) == 0 && deadPerson.countHeirByRelation(SON) == 0
                && deadPerson.countHeirByRelation(GRAND_SON) == 0 && deadPerson.getHeir(FATHER) == null
                && deadPerson.getHeir(PATERNAL_GRAND_FATHER) == null) {
            deadPerson.getAsabaat().add(this);
            setAsaba(true);
            return 0;
        }
        /*
         * // conditions for being mahjoob: if (deadPerson.hasBrothers() &&
         * deadPerson.getSons().size() == 0 && deadPerson.getGrandSons().size()
         * == 0 && deadPerson.getFather() == null &&
         * deadPerson.getPaternalGrandFather() == null) {
         * 
         * }
         */

		// conditions 1,2: jab aini bhai, allati bhai, haqeeqi behnain, baap,
        // daada aur aulaad main se koi bhi mojood na ho
        if (deadPerson.countHeirByRelation(REAL_BROTHER) == 0
                && deadPerson.countHeirByRelation(PATERNAL_HALF_BROTHER) == 0
                && deadPerson.countHeirByRelation(REAL_SISTER) == 0 && deadPerson.countHeirByRelation(SON) == 0
                && deadPerson.countHeirByRelation(GRAND_SON) == 0 && deadPerson.getHeir(FATHER) == null
                && deadPerson.getHeir(PATERNAL_GRAND_FATHER) == null) {
            // condition 1: jab ek ho
            if (deadPerson.countHeirByRelation(PATERNAL_HALF_SISTER) == 1) {
                return totalParts / 2.0;
            }
            // condition 2: jab ek se zyada hon
            if (deadPerson.countHeirByRelation(PATERNAL_HALF_SISTER) > 1) {
                return totalParts * 2.0 / 3.0;
            }
        }

		// condition 3: jab sirf ek aini behn mojood ho. aini bhai, baap, daada,
        // aur aulaad main se koi bhi na ho
        if (deadPerson.countHeirByRelation(REAL_SISTER) == 1 && deadPerson.countHeirByRelation(REAL_BROTHER) == 0
                && deadPerson.countHeirByRelation(SON) == 0 && deadPerson.countHeirByRelation(GRAND_SON) == 0
                && deadPerson.getHeir(FATHER) == null && deadPerson.getHeir(PATERNAL_GRAND_FATHER) == null) {
            return totalParts / 6.0;
        }

        return 0;
    }

}
