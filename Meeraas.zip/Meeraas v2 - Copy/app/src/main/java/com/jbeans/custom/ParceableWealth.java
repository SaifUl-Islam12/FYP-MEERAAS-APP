package com.jbeans.custom;

import android.os.Parcel;
import android.os.Parcelable;

import com.jbeans.model.Heir;
import com.jbeans.model.Wealth;

/**
 * Created by Saeed on 7/12/2017.
 */

public class ParceableWealth implements Parcelable {
    private Wealth wealth;
    private int noOfSiblingsRelations = 10;
    private int noOfChildsRelations = 6;
    private int noOfParentsRelations = 8;
    private int noOfUncleAndChilds = 8;

    public Wealth getWealth(){
        return this.wealth;
    }

    public ParceableWealth(Wealth wealth){
        super();
        this.wealth = wealth;
    }

    private ParceableWealth(Parcel parcel){
        wealth = new Wealth("");
        wealth.setWealth(parcel.readDouble());
        // spouse
        int[] spouse = new int[2];
        parcel.readIntArray(spouse);
        if(spouse[0] > 0)
            wealth.addHusband();
        wealth.addWives(spouse[1]);
        // parents
        boolean[] parents = new boolean[this.noOfParentsRelations];
        parcel.readBooleanArray(parents);
        if(parents[0])
            wealth.addFather();
        if(parents[1])
            wealth.addPaternalGrandFather();
        if(parents[2])
            wealth.addPaternalGrandGrandFather();
        if(parents[3])
            wealth.addPaternalGrandMother();
        if(parents[4])
            wealth.addPaternalGrandGrandMother();
        if(parents[5])
            wealth.addMother();
        if(parents[6])
            wealth.addMaternalGrandMother();
        if(parents[7])
            wealth.addMaternalGrandGrandMother();

        //siblings and their childs
        int[] siblingsCount = new int[this.noOfSiblingsRelations];
        parcel.readIntArray(siblingsCount);
        this.wealth.addRealBrother(siblingsCount[0]);
        this.wealth.addRealSister(siblingsCount[1]);
        this.wealth.addPaternalHalfBrother(siblingsCount[2]);
        this.wealth.addPaternalHalfSister(siblingsCount[3]);
        this.wealth.addMaternalHalfBrother(siblingsCount[4]);
        this.wealth.addMaternalHalfSister(siblingsCount[5]);
        this.wealth.addFullNephews(siblingsCount[6]);
        this.wealth.addFullNephewsSons(siblingsCount[7]);
        this.wealth.addPaternalNephews(siblingsCount[8]);
        this.wealth.addPaternalNephewsSons(siblingsCount[9]);

        //childs
        int[] childsCount = new int[this.noOfChildsRelations];
        parcel.readIntArray(childsCount);
        this.wealth.addSons(childsCount[0]);
        this.wealth.addGrandSons(childsCount[1]);
        this.wealth.addDaughters(childsCount[3]);
        this.wealth.addGrandDaughters(childsCount[4]);

        // Uncles and their childrens
        int[] uncleChildCount = new int[this.noOfUncleAndChilds];
        parcel.readIntArray(uncleChildCount);
        this.wealth.addFullUncles(uncleChildCount[0]);
        this.wealth.addPaternalPaternalUncles(uncleChildCount[1]);
        this.wealth.addFullCousins(uncleChildCount[2]);
        this.wealth.addFullCousinsSons(uncleChildCount[3]);
        this.wealth.addFullCousinsSonsSons(uncleChildCount[4]);
        this.wealth.addPaternalCousins(uncleChildCount[5]);
        this.wealth.addPaternalCousinsSons(uncleChildCount[6]);
        this.wealth.addPaternalCousinsSonsSons(uncleChildCount[7]);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeDouble(this.wealth.getWealth());
        //spouse
        int[] countHusbWife = new int[]{this.wealth.countHeirByRelation(Heir.HUSBAND), this.wealth.countHeirByRelation(Heir.WIFE)};
        parcel.writeIntArray(countHusbWife);
        // parents
        boolean[] parents = new boolean[this.noOfParentsRelations];
        parents[0] = this.wealth.getHeir(Heir.FATHER) == null?false:true;
        parents[1] = this.wealth.getHeir(Heir.PATERNAL_GRAND_FATHER) == null?false:true;
        parents[2] = this.wealth.getHeir(Heir.PATERNAL_GRAND_GRAND_FATHER) == null?false:true;
        parents[3] = this.wealth.getHeir(Heir.PATERNAL_GRAND_MOTHER) == null?false:true;
        parents[4] = this.wealth.getHeir(Heir.PATERNAL_GRAND_GRAND_MOTHER) == null?false:true;
        parents[5] = this.wealth.getHeir(Heir.MOTHER) == null?false:true;
        parents[6] = this.wealth.getHeir(Heir.MATERNAL_GRAND_MOTHER) == null?false:true;
        parents[7] = this.wealth.getHeir(Heir.MATERNAL_GRAND_GRAND_MOTHER) == null?false:true;
        parcel.writeBooleanArray(parents);
        //siblings
        int[] countSiblings = new int[this.noOfSiblingsRelations];
        countSiblings[0] = this.wealth.countHeirByRelation(Heir.REAL_BROTHER);
        countSiblings[1] = this.wealth.countHeirByRelation(Heir.REAL_SISTER);
        countSiblings[2] = this.wealth.countHeirByRelation(Heir.PATERNAL_HALF_BROTHER);
        countSiblings[3] = this.wealth.countHeirByRelation(Heir.PATERNAL_HALF_SISTER);
        countSiblings[4] = this.wealth.countHeirByRelation(Heir.MATERNAL_HALF_BROTHER);
        countSiblings[5] = this.wealth.countHeirByRelation(Heir.MATERNAL_HALF_SISTER);
        countSiblings[6] = this.wealth.countHeirByRelation(Heir.FULL_NEPHEW);
        countSiblings[7] = this.wealth.countHeirByRelation(Heir.FULL_NEPHEWS_SON);
        countSiblings[8] = this.wealth.countHeirByRelation(Heir.PATERNAL_NEPHEW);
        countSiblings[9] = this.wealth.countHeirByRelation(Heir.PATERNAL_NEPHEWS_SON);
        parcel.writeIntArray(countSiblings);


        //childs
        int[] countChilds = new int[this.noOfChildsRelations];
        countChilds[0] = this.wealth.countHeirByRelation(Heir.SON);
        countChilds[1] = this.wealth.countHeirByRelation(Heir.GRAND_SON);
        countChilds[2] = this.wealth.countHeirByRelation(Heir.GRAND_GRAND_SON);
        countChilds[3] = this.wealth.countHeirByRelation(Heir.DAUGHTER);
        countChilds[4] = this.wealth.countHeirByRelation(Heir.GRAND_DAUGHTER);
        countChilds[5] = this.wealth.countHeirByRelation(Heir.GRAND_GRAND_DAUGHTER);
        parcel.writeIntArray(countChilds);

        // Uncle and their children
        int[] countUncleAndChilds = new int[this.noOfUncleAndChilds];
        countUncleAndChilds[0] = this.wealth.countHeirByRelation(Heir.FULL_PATERNAL_UNCLE);
        countUncleAndChilds[1] = this.wealth.countHeirByRelation(Heir.PATERNAL_PATERNAL_UNCLE);
        countUncleAndChilds[2] = this.wealth.countHeirByRelation(Heir.FULL_COUSIN);
        countUncleAndChilds[3] = this.wealth.countHeirByRelation(Heir.FULL_COUSINS_SON);
        countUncleAndChilds[4] = this.wealth.countHeirByRelation(Heir.FULL_COUSINS_GRANDSON);
        countUncleAndChilds[5] = this.wealth.countHeirByRelation(Heir.PATERNAL_COUSIN);
        countUncleAndChilds[6] = this.wealth.countHeirByRelation(Heir.PATERNAL_COUSINS_SON);
        countUncleAndChilds[7] = this.wealth.countHeirByRelation(Heir.PATERNAL_COUSINS_GRANDSON);
        parcel.writeIntArray(countUncleAndChilds);

    }

    public static final Parcelable.Creator<ParceableWealth> CREATOR =
            new Parcelable.Creator<ParceableWealth>() {
                public ParceableWealth createFromParcel(Parcel in) {
                    return new ParceableWealth(in);
                }

                public ParceableWealth[] newArray(int size) {
                    return new ParceableWealth[size];
                }
            };
}
