package com.jbeans.model;

import com.jbeans.meeraas.DATA;
import com.jbeans.meeraas.R;

public class Mother extends Heir {

    public Mother(String name) {
        super(name);

        if (DATA.getInstance().factor_value==99){
            setNameId(R.string.mother);
        }
        else if (DATA.getInstance().factor_value==111){
            setNameId(R.string.u_mother);
        }
    }

    public double calculateProportion(Wealth deadPerson, double totalParts) {

        if ((deadPerson.countChildrens() == 0 && deadPerson.countGrandChildrens() == 0)
                && deadPerson.countAllBrothersAndSisters() == 0) {
			// note that in below two conditions, the proportion of mother is
            // calculated after
            // subtracting the parts of husband or wife from the total parts
            if ((deadPerson.getHeir(HUSBAND) != null && deadPerson.getHeir(FATHER) != null)) {
                double proportion = deadPerson.getHeir(HUSBAND).calculateProportion(deadPerson, totalParts);
                return (totalParts - proportion) / 3.0;
            }

            if ((deadPerson.getHeir(WIFE) != null && deadPerson.getHeir(FATHER) != null)) {
                double proportion = deadPerson.getHeir(WIFE).calculateProportion(deadPerson, totalParts);
                setProportionString("1/3");
                return (totalParts - proportion) / 3.0;
            }
        }

        if ((deadPerson.countChildrens() == 0 && deadPerson.countGrandChildrens() == 0)
                && deadPerson.countAllBrothersAndSisters() < 2) {
            setProportionString("1/3");

            return totalParts / 3.0;
        }
        if (deadPerson.countChildrens() > 0 || deadPerson.countGrandChildrens() > 0
                || deadPerson.countAllBrothersAndSisters() >= 2) {
            setProportionString("1/6");
            return totalParts / 6.0;
        }

        return 0;

    }

    @Override
    public String toString() {
        // TODO Auto-generated method stub
        return "Mother : " + getProportion() + (isAsaba() ? " + Asaba" : "");
    }

}
