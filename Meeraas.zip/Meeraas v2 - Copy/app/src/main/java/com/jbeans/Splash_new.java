package com.jbeans;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import com.jbeans.meeraas.DATA;
import com.jbeans.meeraas.MainActivity;
import com.jbeans.meeraas.R;
import com.jbeans.meeraas.Selection_Activity;
import com.jbeans.meeraas.Urdu_MainActivity;

public class Splash_new extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_new);


    }


    public void btn_english(View v){

        DATA.getInstance().factor_value=99;
        Intent start=new Intent(Splash_new.this, MainActivity.class);
        startActivity(start);
//        finish();
    }


    public void btn_urdu(View v){

        DATA.getInstance().factor_value=111;
        Intent start=new Intent(Splash_new.this, Urdu_MainActivity.class);
        startActivity(start);
//        finish();
    }
}
