package com.jbeans.model;

import com.jbeans.meeraas.DATA;
import com.jbeans.meeraas.R;

public class Father extends Heir {

    public Father(String name) {
        super(name);
        this.partsIfAsaba = 2;

        if (DATA.getInstance().factor_value==99){
            setNameId(R.string.father);
        }
        else if (DATA.getInstance().factor_value==111){
            setNameId(R.string.u_father);
        }
    }

    public double calculateProportion(Wealth deadPerson, double totalParts) {
        // condition 1: jab mayyat ki muzakkar aulaad mojood ho
        if (deadPerson.countHeirByRelation(SON) > 0 || deadPerson.countHeirByRelation(GRAND_SON) > 0) {
            setProportionString("1/6");
            return totalParts / 6.0;
        }
        // condition 2: jab mayyad ki muannas aulaad mojood ho
        if (deadPerson.countHeirByRelation(DAUGHTER) > 0 || deadPerson.countHeirByRelation(GRAND_DAUGHTER) > 0) {
            deadPerson.setTotalPartsForAsabaat(deadPerson.getTotalPartsForAsabaat() + 1);
            deadPerson.getAsabaat().add(this);
            this.setAsaba(true);
            setProportionString("1/6 + Asaba");
            return totalParts / 6.0;
        }
        
        //deadPerson.setTotalPartsForAsabaat(deadPerson.getTotalPartsForAsabaat() + 1);
        deadPerson.getAsabaat().add(this);
        this.setAsaba(true);
        setConditionId(R.string.asaba_reason_no_child);
        return 0;
    }

    @Override
    public String toString() {
        // TODO Auto-generated method stub
        return "Father : " + getProportion() + (isAsaba() ? " + Asaba" : "");
    }

}
