/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.jbeans.model;

import com.jbeans.meeraas.DATA;
import com.jbeans.meeraas.R;

import static com.jbeans.model.Heir.FATHER;
import static com.jbeans.model.Heir.GRAND_SON;
import static com.jbeans.model.Heir.PATERNAL_GRAND_FATHER;
import static com.jbeans.model.Heir.PATERNAL_HALF_BROTHER;
import static com.jbeans.model.Heir.REAL_BROTHER;
import static com.jbeans.model.Heir.SON;
import java.util.ArrayList;

/**
 *
 * @author Saeed
 */
public class FullPaternalUncle extends Heir {

    public FullPaternalUncle(String name) {
        super(name);
        this.partsIfAsaba = 2;

        if (DATA.getInstance().factor_value==99){
            setNameId(R.string.fpu);
        }
        else if (DATA.getInstance().factor_value==111){
            setNameId(R.string.u_fpu);
        }
        blockedBy = new ArrayList<>();
        blockedBy.add(SON);
        blockedBy.add(GRAND_SON);
        blockedBy.add(FATHER);
        blockedBy.add(PATERNAL_GRAND_FATHER);
        blockedBy.add(REAL_BROTHER);
        blockedBy.add(PATERNAL_HALF_BROTHER);
        blockedBy.add(FULL_NEPHEW);
        blockedBy.add(PATERNAL_NEPHEW);
        blockedBy.add(FULL_NEPHEWS_SON);
        blockedBy.add(PATERNAL_NEPHEWS_SON);
    }

    @Override
    double calculateProportion(Wealth deadPerson, double totalParts) {
        for(String relation:blockedBy){
            if(deadPerson.getHeir(relation) != null){
                setCondition("mahjoob_reason_"+relation);
                return 0;
            }
        }

        setAsaba(true);
        return 0;
    }

}
