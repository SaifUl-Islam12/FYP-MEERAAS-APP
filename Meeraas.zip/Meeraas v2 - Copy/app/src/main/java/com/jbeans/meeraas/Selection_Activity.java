package com.jbeans.meeraas;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.Toast;

public class Selection_Activity extends AppCompatActivity {
    RadioButton english, urdu;
    Button submit;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selection_);
        english = (RadioButton) findViewById(R.id.id_english);
        urdu = (RadioButton) findViewById(R.id.id_urdu);
        submit=(Button)findViewById(R.id.btn_submit);
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (english.isChecked()) {
//                    sharedPreferences=getSharedPreferences("Select_Activity", Context.MODE_PRIVATE);
//                    editor=sharedPreferences.edit();
//                    editor.putString("activity","English");
//                    editor.apply();
//                    editor.commit();
                    DATA.getInstance().factor_value=99;
                    Intent start=new Intent(Selection_Activity.this,MainActivity.class);
                    startActivity(start);
                    Selection_Activity.this.finish();
                } else if (urdu.isChecked()) {
//                    sharedPreferences=getSharedPreferences("Select_Activity", Context.MODE_PRIVATE);
//                    editor=sharedPreferences.edit();
//                    editor.putString("activity","urdu");
//                    editor.apply();
//                    editor.commit()
                    DATA.getInstance().factor_value=111;
                    Toast.makeText(Selection_Activity.this,"Urdu Lenguage are Selected!",Toast.LENGTH_LONG).show();
                    Intent start=new Intent(Selection_Activity.this,Urdu_MainActivity.class);
                    startActivity(start);
                    Selection_Activity.this.finish();

                }
            }
        });
    }
}
