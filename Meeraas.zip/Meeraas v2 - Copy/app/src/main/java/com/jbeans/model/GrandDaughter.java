package com.jbeans.model;

import com.jbeans.meeraas.DATA;
import com.jbeans.meeraas.R;

public class GrandDaughter extends Heir {

	public GrandDaughter(String name) {
		super(name);
                this.partsIfAsaba = 1;

		if (DATA.getInstance().factor_value==99){
			setNameId(R.string.gd);

		}
		else if (DATA.getInstance().factor_value==111){
			setNameId(R.string.u_gd);

		}
	}

	@Override
	double calculateProportion(Wealth deadPerson, double totalParts) {
            if(deadPerson.countHeirByRelation(SON) != 0){
                setCondition("mahjoob_reason_son");
                return 0;
            }
            
		if (deadPerson.countHeirByRelation(SON) == 0 && deadPerson.countHeirByRelation(DAUGHTER) == 0
				&& deadPerson.countHeirByRelation(GRAND_SON) == 0) {
			// jab ek ho aur mayyat ki beti, beta aur pota mojood na ho
			if (deadPerson.countHeirByRelation(GRAND_DAUGHTER) == 1)
				return totalParts / 2.0;
			setProportionString("1/2");

			// jab do ya do se zyada ho aur mayat ki beti beta aur pota mojood
			// na ho
			if (deadPerson.countHeirByRelation(GRAND_DAUGHTER) > 1)
				return totalParts * 2.0 / 3.0;
		}

		// jab ek beti mojood ho aur beta mojood na ho
		if (deadPerson.countHeirByRelation(SON) == 0 && deadPerson.countHeirByRelation(DAUGHTER) == 1)
			return totalParts / 6.0;
		setProportionString("1/6");

		// jab mayyat ka pota mojood ho aur beta beti mojood na hon
		if (deadPerson.countHeirByRelation(SON) == 0 && deadPerson.countHeirByRelation(DAUGHTER) == 0
				&& deadPerson.countHeirByRelation(GRAND_SON) > 0) {
                        deadPerson.getAsabaat().add(this);
			this.setAsaba(true);
                        this.setCondition("asaba_reason_grandSon");
			return 0;
		}

		return 0;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "GrandDaughter : " + getProportion() + (isAsaba() ? " + Asaba" : "");
	}

}
