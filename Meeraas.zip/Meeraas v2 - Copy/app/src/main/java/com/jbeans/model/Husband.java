package com.jbeans.model;

import com.jbeans.meeraas.DATA;
import com.jbeans.meeraas.R;

public class Husband extends Heir {

	public Husband(String name) {
		super(name);
		if (DATA.getInstance().factor_value == 99) {
			setNameId(R.string.husband);
		} else if (DATA.getInstance().factor_value == 111) {
			setNameId(R.string.u_husband);
		}

	}

	public double calculateProportion(Wealth deadPerson, double totalParts) {
		if (deadPerson.countChildrens() > 0 || deadPerson.countGrandChildrens() > 0)

			return totalParts / 4.0;
		setProportionString("1/4");

		return totalParts / 2.0;

	}


}

