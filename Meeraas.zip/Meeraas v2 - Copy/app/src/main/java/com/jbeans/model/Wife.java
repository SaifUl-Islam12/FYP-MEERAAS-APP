package com.jbeans.model;

import com.jbeans.meeraas.DATA;
import com.jbeans.meeraas.R;

public class Wife extends Heir{

	public Wife(String name){
		super(name);
		if (DATA.getInstance().factor_value==99){
			setNameId(R.string.wife);
		}
		else if (DATA.getInstance().factor_value==111){
			setNameId(R.string.u_wife);
		}
	}
        @Override
	public double calculateProportion(Wealth deadPerson, double totalParts) {
		if(deadPerson.countChildrens() > 0 || deadPerson.countGrandChildrens() > 0){
                    setProportionString("1/8");
                    return totalParts/8.0;
                }
		setProportionString("1/4");
		return totalParts/4.0;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "Wife : " + getProportion() + (isAsaba() ? " + Asaba" : "");
	}
	
}
