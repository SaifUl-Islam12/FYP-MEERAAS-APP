package com.jbeans.model;

import com.jbeans.meeraas.DATA;
import com.jbeans.meeraas.R;

public class Son extends Heir{

	public Son(String name){
		super(name);
		this.partsIfAsaba = 2;

		if (DATA.getInstance().factor_value==99){
			setNameId(R.string.son);
		}
		else if (DATA.getInstance().factor_value==111){
			setNameId(R.string.u_son);
		}
	}
	
	public double calculateProportion(Wealth deadPerson, double totalParts) {
            setAsaba(true);
            deadPerson.setTotalPartsForAsabaat(deadPerson.getTotalPartsForAsabaat() + this.getCount()*2);
            deadPerson.getAsabaat().add(this);
            this.setCondition("asaba_reason_itself");
		return 0;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "Son : " + getProportion() + (isAsaba() ? " + Asaba":"");
	}

}
