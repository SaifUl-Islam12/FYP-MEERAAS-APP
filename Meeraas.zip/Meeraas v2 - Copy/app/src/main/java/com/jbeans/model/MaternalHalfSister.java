package com.jbeans.model;

import com.jbeans.meeraas.DATA;
import com.jbeans.meeraas.R;

public class MaternalHalfSister extends Heir {

    public MaternalHalfSister(String name) {
        super(name);

        if (DATA.getInstance().factor_value==99){
            setNameId(R.string.mhs);
        }
        else if (DATA.getInstance().factor_value==111){
            setNameId(R.string.u_mhs);
        }
    }

    @Override
    double calculateProportion(Wealth deadPerson, double totalParts) {
        if (deadPerson.countHeirByRelation(SON) != 0) {
            setCondition("mahjoob_reason_son");
            return 0;
        }
        if (deadPerson.countHeirByRelation(GRAND_SON) != 0) {
            setCondition("mahjoob_reason_grandSon");
            return 0;
        }
        if (deadPerson.getHeir(FATHER) != null) {
            setCondition("mahjoob_reason_father");
            return 0;
        }
        if (deadPerson.getHeir(FATHER) == null && deadPerson.getHeir(PATERNAL_GRAND_FATHER) == null
                && deadPerson.countChildrens() == 0 && deadPerson.countGrandChildrens() == 0) {
            if (deadPerson.getHeir(MATERNAL_HALF_SISTER).getCount() == 1) {
                return totalParts / 6.0;
            }
            if (deadPerson.getHeir(MATERNAL_HALF_SISTER).getCount() >= 2) {
                return totalParts / 3.0;
            }
        }
        return 0;
    }

}
