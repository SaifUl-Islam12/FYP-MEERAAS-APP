package com.jbeans.model;

import com.jbeans.meeraas.DATA;
import com.jbeans.meeraas.R;

public class PaternalGrandFather extends Father {

	public PaternalGrandFather(String name) {
		super(name);
                this.partsIfAsaba = 2;
		setNameId(R.string.pgf);
		if (DATA.getInstance().factor_value==99){
			setNameId(R.string.pgf);
		}
		else if (DATA.getInstance().factor_value==111){
			setNameId(R.string.u_pgf);
		}
	}

	public double calculateProportion(Wealth deadPerson, double totalParts) {
		if (deadPerson.getHeir(FATHER) != null){
			setCondition("mahjoob_reason_father");
			return 0;
		}

		/*if ((deadPerson.countHeirByRelation(SON) > 0 || deadPerson.countHeirByRelation(GRAND_SON) > 0)) {
			return totalParts / 6.0;
		}

		if ((deadPerson.countHeirByRelation(DAUGHTER) > 0 || deadPerson.countHeirByRelation(GRAND_DAUGHTER) > 0)) {
			setAsaba(true);
			return totalParts / 6.0;
		}

		if ((deadPerson.countHeirByRelation(SON) + deadPerson.countHeirByRelation(GRAND_SON)) == 0) {

			setAsaba(true);
			return 0;
		}
		return 0;
		*/



        return super.calculateProportion(deadPerson, totalParts);
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString();
	}

}
