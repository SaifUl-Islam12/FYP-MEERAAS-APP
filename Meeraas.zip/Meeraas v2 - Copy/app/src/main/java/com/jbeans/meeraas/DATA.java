package com.jbeans.meeraas;

public class DATA {
    public static int factor_value;
    private static final DATA ourInstance = new DATA();

    public static DATA getInstance() {
        return ourInstance;
    }

    private DATA() {

    }

}
