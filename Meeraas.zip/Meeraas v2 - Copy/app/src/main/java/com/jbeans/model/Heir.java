package com.jbeans.model;

import com.jbeans.meeraas.R;

import java.util.ArrayList;

public abstract class Heir extends Person {

    public static final String SON = "son";
    public static final String GRAND_SON = "gs";
    public static final String GRAND_GRAND_SON = "ggs";
    public static final String DAUGHTER = "daughter";
    public static final String GRAND_DAUGHTER = "gd";
    public static final String GRAND_GRAND_DAUGHTER = "ggd";
    public static final String FATHER = "father";
    public static final String PATERNAL_GRAND_FATHER = "pgf";
    public static final String PATERNAL_GRAND_GRAND_FATHER = "pggf";
    public static final String PATERNAL_GRAND_MOTHER = "pgm";
    public static final String PATERNAL_GRAND_GRAND_MOTHER = "pggm";
    public static final String MOTHER = "mother";
    public static final String MATERNAL_GRAND_FATHER = "mgf";
    public static final String MATERNAL_GRAND_GRAND_FATHER = "mggf";
    public static final String MATERNAL_GRAND_MOTHER = "mgm";
    public static final String MATERNAL_GRAND_GRAND_MOTHER = "mggm";
    public static final String REAL_BROTHER = "fb";
    public static final String PATERNAL_HALF_BROTHER = "phb";
    public static final String MATERNAL_HALF_BROTHER = "mhb";
    public static final String REAL_SISTER = "fs";
    public static final String PATERNAL_HALF_SISTER = "phs";
    public static final String MATERNAL_HALF_SISTER = "mhs";
    public static final String WIFE = "wife";
    public static final String HUSBAND = "husband";
    public static final String FULL_NEPHEW="fn";
    public static final String FULL_NEPHEWS_SON="fns";
    public static final String PATERNAL_NEPHEW="pn";
    public static final String PATERNAL_NEPHEWS_SON="pns";
    public static final String FULL_COUSIN="fc";
    public static final String PATERNAL_COUSIN="phc";
    public static final String FULL_COUSINS_SON="fcs";
    public static final String PATERNAL_COUSINS_SON="phcs";
    public static final String FULL_COUSINS_GRANDSON="fcgs";
    public static final String PATERNAL_COUSINS_GRANDSON="pcgs";
    public static final String FULL_PATERNAL_UNCLE="fpu";
    public static final String PATERNAL_PATERNAL_UNCLE="ppu";

    
    private boolean isAsaba = false;
    private boolean isAlive = true;
    private int count;
    private double proportion;
    private String proportionString;
    private String condition;
    private int conditionId;
    protected double partsIfAsaba = 0;

    private int nameId = -1;
    public double getPartsIfAsaba() {
        return partsIfAsaba;
    }
    
    protected ArrayList<String> blockedBy=null;

    public Heir(String name) {
        super();
        this.name = name;
        this.count = 1;
        this.proportion = 0.0;
        this.conditionId = R.string.no_reason;
    }

    abstract double calculateProportion(Wealth deadPerson, double totalParts);

    public boolean isAsaba() {
        return isAsaba;
    }

    public void setAsaba(boolean isAsaba) {
        this.isAsaba = isAsaba;
    }

    public double getProportion() {
        return proportion;
    }

    public void setProportion(double proportion) {
        this.proportion = proportion;
    }

    public boolean isAlive() {
        return isAlive;
    }

    public void setAlive(boolean isAlive) {
        this.isAlive = isAlive;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public String getCondition() {
        return condition;
    }

    public void setCondition(String condition) {
        this.condition = condition;
    }

    public String getProportionString() {
        return proportionString;
    }

    public void setProportionString(String proportionString) {
        this.proportionString = proportionString;
    }


    public int getNameId() {
        return nameId;
    }

    public void setNameId(int nameId) {
        this.nameId = nameId;
    }

    public int getConditionId() {
        return conditionId;
    }

    public void setConditionId(int conditionId) {
        this.conditionId = conditionId;
    }
}
