package com.jbeans.model;

import com.jbeans.meeraas.DATA;
import com.jbeans.meeraas.R;

public class Daughter  extends Heir {
	
	public Daughter(String name){
		super(name);this.partsIfAsaba = 1;

		if (DATA.getInstance().factor_value==99){
			setNameId(R.string.daughter);
		}
		else if (DATA.getInstance().factor_value==111){
			setNameId(R.string.u_daughter);
		}
	}

	public double calculateProportion(Wealth deadPerson, double totalParts) {
		if(deadPerson.countHeirByRelation(SON) == 0){
			if(deadPerson.countHeirByRelation(DAUGHTER) == 1){
                            setProportionString("1/2");
                            return totalParts/2.0;
                        }
                        else{
                            setProportionString("2/3+");
                            return totalParts*2.0/3.0;
                        }
		}
		
		if(deadPerson.countHeirByRelation(SON) > 0){
                    deadPerson.setTotalPartsForAsabaat(deadPerson.getTotalPartsForAsabaat() + this.getCount());
                            deadPerson.getAsabaat().add(this);
                            setProportionString("Half of Son");
			setConditionId(R.string.asaba_reason_son);
			setAsaba(true);
                }
		
		return 0;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "Daughter : " + getProportion() + (isAsaba() ? " + Asaba":"");
	}

}
