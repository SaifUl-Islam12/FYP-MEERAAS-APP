package com.jbeans.model;

import com.jbeans.meeraas.DATA;
import com.jbeans.meeraas.R;
public class FullBrother extends Heir {
    public FullBrother(String name) {
        super(name);
        this.partsIfAsaba = 2;
        if (DATA.getInstance().factor_value==99){
            setNameId(R.string.fb);
        }
        else if (DATA.getInstance().factor_value==111){
            setNameId(R.string.u_fb);
        }
    }
    public double calculateProportion(Wealth deadPerson, double totalParts) {
        // Check if mahjoob
        if (deadPerson.countHeirByRelation(SON) != 0) {
            setConditionId(R.string.mahjoob_reason_son);
            return 0.0;
        } else if (deadPerson.countHeirByRelation(GRAND_SON) != 0) {
            setConditionId(R.string.mahjoob_reason_gs);
            return 0.0;
        } else if (deadPerson.getHeir(FATHER) != null) {
            setConditionId(R.string.mahjoob_reason_father);
            return 0.0;
        } else if (deadPerson.getHeir(PATERNAL_GRAND_FATHER) != null)
        {
            setConditionId(R.string.mahjoob_reason_pgf);
            return 0.0;
        }
//        if (deadPerson.countHeirByRelation(SON) == 0 && deadPerson.countHeirByRelation(GRAND_SON) == 0
//                && deadPerson.getHeir(FATHER) == null && deadPerson.getHeir(PATERNAL_GRAND_FATHER) == null) {
//            deadPerson.setTotalPartsForAsabaat(deadPerson.getTotalPartsForAsabaat() + this.getCount() * 2);
//            deadPerson.getAsabaat().add(this);
//            setAsaba(true);
//            setCondition("asaba_reason_noChildren_noParents");
//            return 0.0;
//        }
        setAsaba(true);
        setConditionId(R.string.asaba_reason_no_child_no_parent);
        return 0;
      }
     @Override
      public String toString()
     {
         // TODO Auto-generated method stub
         return "Real Brother : " + getProportion() + (isAsaba() ? " + Asaba" : "" + getCondition());
      }

}
