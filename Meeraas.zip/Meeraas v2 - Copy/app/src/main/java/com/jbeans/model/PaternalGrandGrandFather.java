package com.jbeans.model;

import com.jbeans.meeraas.DATA;
import com.jbeans.meeraas.R;

public class PaternalGrandGrandFather extends PaternalGrandFather {

	public PaternalGrandGrandFather(String name) {
		super(name);
                this.partsIfAsaba = 2;

		if (DATA.getInstance().factor_value==99){
			setNameId(R.string.pggf);
		}
		else if (DATA.getInstance().factor_value==111){
			setNameId(R.string.u_pggf);
		}
	}

	@Override
	public double calculateProportion(Wealth deadPerson, double totalParts) {
		
		if(deadPerson.getHeir(PATERNAL_GRAND_FATHER) != null){
			setCondition("mahjoob_reason_paternalGrandFather");
			return 0.0;
		}
		
		return super.calculateProportion(deadPerson, totalParts);
	}
	
}
