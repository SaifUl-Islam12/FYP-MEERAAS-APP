/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.jbeans.model;

import com.jbeans.meeraas.DATA;
import com.jbeans.meeraas.R;

/**
 *
 * @author Saeed
 */
class MaternalGrandGrandMother extends MaternalGrandMother{

    public MaternalGrandGrandMother(String name) {
        super(name);

        if (DATA.getInstance().factor_value==99){
            setNameId(R.string.mggm);
        }
        else if (DATA.getInstance().factor_value==111){
            setNameId(R.string.u_mggm);
        }
    }

    @Override
    double calculateProportion(Wealth deadPerson, double totalParts) {
        
        if(deadPerson.getHeir(Heir.MOTHER)!= null || deadPerson.getHeir(Heir.MATERNAL_GRAND_MOTHER) != null){
            return 0.0;
        }
        
        return super.calculateProportion(deadPerson, totalParts); //To change body of generated methods, choose Tools | Templates.
    }
    
    
    
}
