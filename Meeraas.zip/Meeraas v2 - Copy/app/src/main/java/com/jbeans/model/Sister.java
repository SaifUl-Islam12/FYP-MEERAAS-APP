package com.jbeans.model;

import com.jbeans.meeraas.DATA;
import com.jbeans.meeraas.R;

public class Sister extends Heir {

	public Sister(String name) {
		super(name);this.partsIfAsaba = 1;

		if (DATA.getInstance().factor_value==99){
			setNameId(R.string.fs);
		}
		else if (DATA.getInstance().factor_value==111){
			setNameId(R.string.u_fs);
		}
	}

	public double calculateProportion(Wealth deadPerson, double totalParts) {
		if (deadPerson.countHeirByRelation(SON) == 0 && deadPerson.countHeirByRelation(GRAND_SON) == 0
				&& deadPerson.getHeir(FATHER) == null && deadPerson.getHeir(PATERNAL_GRAND_FATHER) == null) {
			if (deadPerson.countHeirByRelation(DAUGHTER) == 0 && deadPerson.countHeirByRelation(GRAND_DAUGHTER) == 0
					&& deadPerson.countHeirByRelation(REAL_BROTHER) == 0) {
				if (deadPerson.countHeirByRelation(REAL_SISTER) == 1)
					return totalParts / 2.0;

				if (deadPerson.countHeirByRelation(REAL_SISTER) > 1)
					return totalParts * 2.0 / 3.0;
			}

			if (deadPerson.countHeirByRelation(REAL_BROTHER) == 0
					&& (deadPerson.countHeirByRelation(DAUGHTER) + deadPerson.countHeirByRelation(GRAND_DAUGHTER)) == 1) {
                            deadPerson.setTotalPartsForAsabaat(deadPerson.getTotalPartsForAsabaat() + this.getCount());
                            deadPerson.getAsabaat().add(this);
                            this.setCondition("asaba_reason_onlyOneFemaleChild");
                            setAsaba(true);
				return 0;
			}

			if (deadPerson.countHeirByRelation(REAL_BROTHER) > 0) {
                            deadPerson.setTotalPartsForAsabaat(deadPerson.getTotalPartsForAsabaat() + this.getCount());
                            deadPerson.getAsabaat().add(this);
				setAsaba(true);
                                setCondition("asaba_reason_fullBrother");
				return 0;
			}
		}

		return 0;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "Sister : " + getProportion() + (isAsaba() ? " + Asaba" : "");
	}
}
