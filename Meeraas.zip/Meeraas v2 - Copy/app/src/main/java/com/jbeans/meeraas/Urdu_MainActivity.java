package com.jbeans.meeraas;

import android.app.Activity;
import android.app.Application;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.text.Editable;
import android.text.method.KeyListener;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.jbeans.custom.ParceableWealth;
import com.jbeans.model.Heir;
import com.jbeans.model.Wealth;

public class Urdu_MainActivity extends Activity {
    //husband Wife
    private CheckBox cbHusband;
    private EditText tfWife;
    //  Parents Controls
    private CheckBox cbFather;
    private CheckBox cbPgf;
    private CheckBox cbPggf;
    private CheckBox cbPgm;
    private CheckBox cbPggm;
    private CheckBox cbMother;
    private CheckBox cbMgm;
    private CheckBox cbMggm;
    //Siblings Controls
    private EditText tfFb;
    private EditText tfFs;
    private EditText tfPhb;
    private EditText tfPhs;
    private EditText tfMhb;
    private EditText tfMhs;
    private EditText tfFn;
    private EditText tfFns;
    private EditText tfPn;
    private EditText tfPns;

    // Childs Controls
    private EditText tfSon;
    private EditText tfGs;
    private EditText tfGgs;
    private EditText tfDaughter;
    private EditText tfGd;
    private EditText tfGgd;

    //Uncle and their childs
    private EditText tfFpu;
    private EditText tfPpu;
    private EditText tfFc;
    private EditText tfFcs;
    private EditText tfFcgs;
    private EditText tfPc;
    private EditText tfPcs;
    private EditText tfPcgs;
   Button btnrules;

    LinearLayout ll_spouse
            ,ll_parents
            ,ll_siblings
            ,ll_childs
            ,ll_uncle;

    ImageView arrow_spouse
            ,arrow_parent
            ,arrow_siblings
            ,arrow_childs
            ,arrow_uncle;

    boolean arrow_values[];
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.test);


        arrow_values = new boolean[5];
        arrow_values[0]=false;
        arrow_values[1]=false;
        arrow_values[2]=false;
        arrow_values[3]=false;
        arrow_values[4]=false;

        ll_spouse = findViewById(R.id.ll_spouse);
        ll_parents = findViewById(R.id.ll_parent);
        ll_siblings = findViewById(R.id.ll_siblings);
        ll_childs = findViewById(R.id.ll_childs);
        ll_uncle = findViewById(R.id.ll_uncle);

        arrow_spouse = findViewById(R.id.arrow_spouse);
        arrow_parent = findViewById(R.id.arrow_parrent);
        arrow_siblings = findViewById(R.id.arrow_sibling);
        arrow_childs = findViewById(R.id.arrow_childs);
        arrow_uncle = findViewById(R.id.arrow_uncles);

        // spouse
        tfWife = (EditText) findViewById(R.id.tfWife);
        cbHusband = (CheckBox) findViewById(R.id.cbHusband);
        btnrules =(Button)findViewById(R.id.btn_rules) ;
        btnrules.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            Intent intent = new Intent(Urdu_MainActivity.this,Urdu_Rulles.class);
            startActivity(intent);
            }
        });
        //parents controls
        cbFather = (CheckBox) findViewById(R.id.cbFather);
        cbPgf = (CheckBox) findViewById(R.id.cbPgf);
        cbPggf = (CheckBox) findViewById(R.id.cbPggf);
        cbPgm = (CheckBox) findViewById(R.id.cbPgm);
        cbPggm= (CheckBox) findViewById(R.id.cbPggm);
        cbMother = (CheckBox) findViewById(R.id.cbMother);
        cbMgm = (CheckBox) findViewById(R.id.cbMgm);
        cbMggm = (CheckBox) findViewById(R.id.cbMggm);

        // siblings controls
        tfFb = (EditText) findViewById(R.id.tfFb);
        tfPhb = (EditText) findViewById(R.id.tfPhb);
        tfPhs = (EditText) findViewById(R.id.tfPhs);
        tfFs = (EditText) findViewById(R.id.tfFs);
        tfMhs = (EditText) findViewById(R.id.tfMhs);
        tfMhb = (EditText) findViewById(R.id.tfMhb);
        tfFn = (EditText) findViewById(R.id.tfFn);
        tfFns = (EditText) findViewById(R.id.tfFns);
        tfPn = (EditText) findViewById(R.id.tfPn);
        tfPns = (EditText) findViewById(R.id.tfPns);

        // childs controls
        tfSon = (EditText) findViewById(R.id.tfSon);
        tfDaughter = (EditText) findViewById(R.id.tfDaughter);
        tfGs = (EditText) findViewById(R.id.tfGs);
        tfGd = (EditText) findViewById(R.id.tfGd);
        tfGgs = (EditText) findViewById(R.id.tfGgs);
        tfGgd = (EditText) findViewById(R.id.tfGgd);
        // Uncle and their childs
        tfFpu = (EditText) findViewById(R.id.tfFpu);
        tfPpu = (EditText) findViewById(R.id.tfPpu);
        tfFc = (EditText) findViewById(R.id.tfFc);
        tfFcs = (EditText) findViewById(R.id.tfFcs);
        tfFcgs = (EditText) findViewById(R.id.tfFcgs);
        tfPc = (EditText) findViewById(R.id.tfPc);
        tfPcs = (EditText) findViewById(R.id.tfPcs);
        tfPcgs = (EditText) findViewById(R.id.tfPcgs);
    }
    public void calculateInheritance(View view){
        double totalParts = 24;
        Wealth wealthLeft = getData();
        if (wealthLeft.getHeirs().isEmpty()) {
            Toast.makeText(getApplicationContext(), "No Heir present", Toast.LENGTH_SHORT).show();
            //JOptionPane.showMessageDialog(null, resBundle.getString("error_select_heir"));
            return;
        }


        goToWealthInputActivity(wealthLeft);
    }

    public void goToWealthInputActivity(Wealth wealth){
        Intent intent = new Intent(getApplicationContext(), WealthInput.class);
        ParceableWealth pWealth = new ParceableWealth(wealth);
        intent.putExtra("wealth", pWealth);
        startActivity(intent);
    }
    public void husbandChecked(View view){
        CheckBox cbHusband = (CheckBox) view;
        if(((CheckBox) view).isChecked()){
            tfWife.setText("");
            tfWife.setEnabled(false);
        }else{
            tfWife.setEnabled(true);
        }
    }
    private Wealth getData() {
        Wealth wealthLeft;
        wealthLeft = new Wealth("Dead");
        getSpouseData(wealthLeft);
        getParentsData(wealthLeft);
        getSiblingsData(wealthLeft);
        getChildrenData(wealthLeft);
        getUncleAndTheirChildren(wealthLeft);

        return wealthLeft;
    }
    private void getSpouseData(Wealth meeras){
        if(tfWife.getText().length() != 0 && Integer.parseInt(tfWife.getText().toString())<5){
            Integer count = Integer.parseInt(tfWife.getText().toString());
            meeras.addWives(count);
        }
        else{
            if(cbHusband.isChecked()){
                meeras.addHusband();
            }
        }
    }
    private void getChildrenData(Wealth meeras) {
        if (tfSon.getText().length() != 0) {
            Integer count = Integer.parseInt(tfSon.getText().toString());
            meeras.addSons(count);
        }

        if (tfDaughter.getText().length() != 0) {
            Integer count = Integer.parseInt(tfDaughter.getText().toString());
            meeras.addDaughters(count);
        }

        if (tfGs.getText().length() != 0) {
            Integer count = Integer.parseInt(tfGs.getText().toString());
            meeras.addGrandSons(count);

        }

        if (tfGd.getText().length() != 0) {
            Integer count = Integer.parseInt(tfGd.getText().toString());

            meeras.addGrandDaughters(count);

        }

    }

    private void getSiblingsData(Wealth meeras) {
        if (tfFb.getText().length() != 0) {
            Integer count = Integer.parseInt(tfFb.getText().toString());

            meeras.addRealBrother(count);

        }

        if (tfFs.getText().length() != 0) {
            Integer count = Integer.parseInt(tfFs.getText().toString());

            meeras.addRealSister(count);

        }

        if (tfMhb.getText().length() != 0) {
            Integer count = Integer.parseInt(tfMhb.getText().toString());
            meeras.addMaternalHalfBrother(count);

        }

        if (tfMhs.getText().length() != 0) {
            Integer count = Integer.parseInt(tfMhs.getText().toString());
            meeras.addMaternalHalfSister(count);

        }

        if (tfPhb.getText().length() != 0) {
            Integer count = Integer.parseInt(tfPhb.getText().toString());

            meeras.addPaternalHalfBrother(count);

        }

        if (tfPhs.getText().length() != 0) {
            Integer count = Integer.parseInt(tfPhs.getText().toString());
            meeras.addPaternalHalfSister(count);
        }

        if (tfFn.getText().length() != 0) {
            Integer count = Integer.parseInt(tfFn.getText().toString());
            meeras.addFullNephews(count);
        }

        if (tfFns.getText().length() != 0) {
            Integer count = Integer.parseInt(tfFns.getText().toString());
            meeras.addFullNephewsSons(count);
        }

        if (tfPn.getText().length() != 0) {
            Integer count = Integer.parseInt(tfPn.getText().toString());
            meeras.addPaternalNephews(count);
        }

        if (tfPns.getText().length() != 0) {
            Integer count = Integer.parseInt(tfPns.getText().toString());
            meeras.addPaternalNephewsSons(count);
        }

    }

    private void getUncleAndTheirChildren(Wealth meeras){
        if (tfFpu.getText().length() != 0) {
            Integer count = Integer.parseInt(tfFpu.getText().toString());
            meeras.addFullUncles(count);
        }

        if (tfPpu.getText().length() != 0) {
            Integer count = Integer.parseInt(tfPpu.getText().toString());
            meeras.addPaternalPaternalUncles(count);
        }

        if (tfFc.getText().length() != 0) {
            Integer count = Integer.parseInt(tfFc.getText().toString());
            meeras.addFullCousins(count);
        }

        if (tfFcs.getText().length() != 0) {
            Integer count = Integer.parseInt(tfFcs.getText().toString());
            meeras.addFullCousinsSons(count);
        }

        if (tfFcgs.getText().length() != 0) {
            Integer count = Integer.parseInt(tfFcgs.getText().toString());
            meeras.addFullCousinsSonsSons(count);
        }

        if (tfPc.getText().length() != 0) {
            Integer count = Integer.parseInt(tfPc.getText().toString());
            meeras.addPaternalCousins(count);
        }

        if (tfPcs.getText().length() != 0) {
            Integer count = Integer.parseInt(tfPcs.getText().toString());
            meeras.addPaternalCousinsSons(count);
        }

        if (tfPcgs.getText().length() != 0) {
            Integer count = Integer.parseInt(tfPcgs.getText().toString());
            meeras.addPaternalCousinsSonsSons(count);
        }

    }

    private void getParentsData(Wealth meeras) {
        if (cbFather.isChecked()) {
            meeras.addFather();
        }
        if (cbMother.isChecked()) {
            meeras.addMother();
        }
        if (cbPgf.isChecked()) {
            meeras.addPaternalGrandFather();
        }
        if (cbPgm.isChecked()) {
            meeras.addPaternalGrandMother();
        }
        if (cbMgm.isChecked()) {
            meeras.addMaternalGrandMother();
        }
        if (cbMggm.isChecked()) {
            meeras.addMaternalGrandGrandMother();
        }
        if (cbPggf.isChecked()) {
            meeras.addPaternalGrandGrandFather();
        }
        if (cbPggm.isChecked()) {
            meeras.addPaternalGrandGrandMother();
        }
    }


    public void title_click(View v){
        if(v.getId() == R.id.ll_title_spouse){

            if(arrow_values[0]){
                ll_spouse.setVisibility(View.GONE);
                arrow_values[0]=false;
                arrow_spouse.setImageResource(R.drawable.down_white_arrow);

            }else {

                ll_spouse.setVisibility(View.VISIBLE);
                arrow_values[0]=true;
                arrow_spouse.setImageResource(R.drawable.up_white_arrow);

            }
        }else  if(v.getId() == R.id.ll_title_parents){

            if(arrow_values[1]){
                ll_parents.setVisibility(View.GONE);
                arrow_values[1]=false;
                arrow_parent.setImageResource(R.drawable.down_white_arrow);

            }else {

                ll_parents.setVisibility(View.VISIBLE);
                arrow_values[1]=true;
                arrow_parent.setImageResource(R.drawable.up_white_arrow);

            }
        }else  if(v.getId() == R.id.ll_title_siblings){

            if(arrow_values[2]){
                ll_siblings.setVisibility(View.GONE);
                arrow_values[2]=false;
                arrow_siblings.setImageResource(R.drawable.down_white_arrow);

            }else {

                ll_siblings.setVisibility(View.VISIBLE);
                arrow_values[2]=true;
                arrow_siblings.setImageResource(R.drawable.up_white_arrow);

            }
        }else  if(v.getId() == R.id.ll_title_childs){

            if(arrow_values[3]){
                ll_childs.setVisibility(View.GONE);
                arrow_values[3]=false;
                arrow_childs.setImageResource(R.drawable.down_white_arrow);

            }else {

                ll_childs.setVisibility(View.VISIBLE);
                arrow_values[3]=true;
                arrow_childs.setImageResource(R.drawable.up_white_arrow);

            }
        }else  if(v.getId() == R.id.ll_title_uncle){

            if(arrow_values[4]){
                ll_uncle.setVisibility(View.GONE);
                arrow_values[4]=false;
                arrow_uncle.setImageResource(R.drawable.down_white_arrow);

            }else {

                ll_uncle.setVisibility(View.VISIBLE);
                arrow_values[4]=true;
                arrow_uncle.setImageResource(R.drawable.up_white_arrow);

            }
        }

    }

}
