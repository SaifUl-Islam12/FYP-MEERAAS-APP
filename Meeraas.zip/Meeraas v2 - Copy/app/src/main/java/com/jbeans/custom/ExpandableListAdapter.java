package com.jbeans.custom;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.TextView;

import com.jbeans.meeraas.R;
import com.jbeans.model.Heir;
import com.jbeans.model.Wealth;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

/**
 * Created by Saeed on 7/13/2017.
 */

public class ExpandableListAdapter extends BaseExpandableListAdapter {
    private List<Integer> groupsNames = new ArrayList<>();
    private Wealth wealth;
    private List<List<Heir>> groups = new ArrayList<>();
    private LayoutInflater inflater;
    private Resources resources = null;

    public ExpandableListAdapter(Wealth wealth, LayoutInflater inflater, Resources resources){
        super();
        this.wealth = wealth;
        extractGroups(wealth);
        this.inflater = inflater;
        this.resources = resources;
        //associateStringIds();
    }

    /*private void associateStringIds(){
        for(Heir heir:this.wealth.getHeirs().values()){
            switch (heir.getName()){
                case Heir.FATHER:
                    heir.setNameId(R.string.father);
                    break;
                case Heir.MOTHER:
                    heir.setNameId(R.string.mother);
                    break;
                case Heir.PATERNAL_GRAND_FATHER:
                    heir.setNameId(R.string.pgf);
                    break;
                case Heir.PATERNAL_GRAND_MOTHER:
                    heir.setNameId(R.string.pgm);
                    break;
                case Heir.PATERNAL_GRAND_GRAND_FATHER:
                    heir.setNameId(R.string.pggf);
                    break;
                case Heir.PATERNAL_GRAND_GRAND_MOTHER:
                    heir.setNameId(R.string.pggm);
                    break;
                case Heir.MATERNAL_GRAND_MOTHER:
                    heir.setNameId(R.string.mgm);
                    break;
                case Heir.MATERNAL_GRAND_GRAND_MOTHER:
                    heir.setNameId(R.string.mggm);
                    break;
                case Heir.REAL_BROTHER:
                    heir.setNameId(R.string.fb);
                    break;
                case Heir.MATERNAL_HALF_SISTER:
                    heir.setNameId(R.string.mhs);
                case Heir.MATERNAL_HALF_BROTHER:
                    heir.setNameId(R.string.mhb);
                case Heir.REAL_SISTER:
                    heir.setNameId(R.string.fs);
                case Heir.PATERNAL_HALF_BROTHER:
                    heir.setNameId(R.string.phb);
                case Heir.PATERNAL_HALF_SISTER:
                    heir.setNameId(R.string.phs);
                case Heir.FULL_NEPHEW:
                    heir.setNameId(R.string.fn);
                case Heir.FULL_NEPHEWS_SON:
                    heir.setNameId(R.string.fns);
                case Heir.PATERNAL_NEPHEW:
                    heir.setNameId(R.string.pn);
                case Heir.PATERNAL_NEPHEWS_SON:
                    heir.setNameId(R.string.pns);
                    siblings.add(heir);
                    break;
                case Heir.HUSBAND:
                    heir.setNameId(R.string.husband);
                case Heir.WIFE:
                    heir.setNameId(R.string.wife);
                    spouse.add(heir);
                    break;
                case Heir.SON:
                    heir.setNameId(R.string.son);
                case Heir.GRAND_SON:
                    heir.setNameId(R.string.gs);
                case Heir.DAUGHTER:
                    heir.setNameId(R.string.daughter);
                case Heir.GRAND_DAUGHTER:
                    heir.setNameId(R.string.gd);
                case Heir.GRAND_GRAND_SON:
                    heir.setNameId(R.string.ggs);
                case Heir.GRAND_GRAND_DAUGHTER:
                    heir.setNameId(R.string.ggd);
                    childs.add(heir);
                    break;
                case Heir.FULL_PATERNAL_UNCLE:
                    heir.setNameId(R.string.fpu);
                case Heir.PATERNAL_PATERNAL_UNCLE:
                    heir.setNameId(R.string.ppu);
                case Heir.FULL_COUSIN:
                    heir.setNameId(R.string.fc);
                case Heir.FULL_COUSINS_SON:
                    heir.setNameId(R.string.fcs);
                case Heir.FULL_COUSINS_GRANDSON:
                    heir.setNameId(R.string.fcgs);
                case Heir.PATERNAL_COUSIN:
                    heir.setNameId(R.string.pc);
                case Heir.PATERNAL_COUSINS_SON:
                    heir.setNameId(R.string.pcs);
                case Heir.PATERNAL_COUSINS_GRANDSON:
                    heir.setNameId(R.string.pcgs);
                    uncleAndChilds.add(heir);
            }
        }
    }*/

    @Override
    public int getGroupCount() {
        return groups.size();
    }

    @Override
    public int getChildrenCount(int i) {
        return groups.get(i).size();
        /*
        if(i==0)
            return parents.size();
        else if(i==1)
            return siblings.size();
        else if(i==2)
            return childs.size();
        else if(i==3)
            return spouse.size();*/

        //return 0;
    }

    @Override
    public Object getGroup(int i) {
        return resources.getString((int)getGroupId(i));
    }

    @Override
    public Object getChild(int i, int i1) {
        /*if(i==0)
            return parents.get(i1);
        else if(i==1)
            return siblings.get(i1);
        else if(i==2)
            return childs.get(i1);
        else if(i==3)
            return husWife.get(i1);*/

        return null;
    }

    @Override
    public long getGroupId(int i) {
        return groupsNames.get(i);
    }

    @Override
    public long getChildId(int group, int child) {
        return groups.get(group).get(child).getNameId();
    }

    @Override
    public boolean hasStableIds() {
        return false;
    }

    @Override
    public View getGroupView(int i, boolean b, View view, ViewGroup viewGroup) {
        String headerTitle = resources.getString((int)getGroupId(i));
        if (view == null) {
            view = inflater.inflate(R.layout.list_group, null);
        }

        TextView lblListHeader = (TextView) view
                .findViewById(R.id.lblListHeader);
        lblListHeader.setTypeface(null, Typeface.BOLD);
        lblListHeader.setText(headerTitle.toUpperCase());

        return view;
    }

    @Override
    public View getChildView(int groupPosition, int childPosition, boolean b, View view, ViewGroup viewGroup) {
        final String childText = resources.getString((int)getChildId(groupPosition, childPosition));

        if (view == null) {
            view = this.inflater.inflate(R.layout.list_item, null);
        }
        Heir heir = getHeirInGroup(groupPosition, childPosition);

        TextView lblRelation = (TextView) view
                .findViewById(R.id.lblRelation);
        TextView lblCount = (TextView) view
                .findViewById(R.id.lblCount);
        TextView lblCondition = (TextView) view
                .findViewById(R.id.lblCondition);
        TextView lblProportion = (TextView) view
                .findViewById(R.id.lblProportion);
        TextView lblPropString = (TextView) view.findViewById(R.id.lblPropString);

        lblRelation.setText(childText);
        lblCount.setText(heir.getCount()+"");
        lblCondition.setText(resources.getString(heir.getConditionId()));
        lblPropString.setText(heir.getProportionString());
        lblProportion.setText(String.format("%.2f",heir.getProportion()));

        return view;
    }

    @Override
    public boolean isChildSelectable(int i, int i1) {
        return false;
    }


    public int countChildrenInGroup(String group){
       return 0;
    }

    public void extractGroups(Wealth wealth){
        List<Heir> parents = new ArrayList<>();
        List<Heir> siblings = new ArrayList<>();
        List<Heir> childs = new ArrayList<>();
        List<Heir> spouse = new ArrayList<>();
        List<Heir> uncleAndChilds = new ArrayList<>();
        for(Heir heir:this.wealth.getHeirs().values()){
            switch (heir.getName()){
                case Heir.FATHER:
                case Heir.MOTHER:
                case Heir.PATERNAL_GRAND_FATHER:
                case Heir.PATERNAL_GRAND_MOTHER:
                case Heir.PATERNAL_GRAND_GRAND_FATHER:
                case Heir.PATERNAL_GRAND_GRAND_MOTHER:
                case Heir.MATERNAL_GRAND_MOTHER:
                case Heir.MATERNAL_GRAND_GRAND_MOTHER:
                    parents.add(heir);
                    break;
                case Heir.REAL_BROTHER:
                case Heir.MATERNAL_HALF_SISTER:
                case Heir.MATERNAL_HALF_BROTHER:
                case Heir.REAL_SISTER:
                case Heir.PATERNAL_HALF_BROTHER:
                case Heir.PATERNAL_HALF_SISTER:
                case Heir.FULL_NEPHEW:
                case Heir.FULL_NEPHEWS_SON:
                case Heir.PATERNAL_NEPHEW:
                case Heir.PATERNAL_NEPHEWS_SON:
                    siblings.add(heir);
                    break;
                case Heir.HUSBAND:
                case Heir.WIFE:
                    spouse.add(heir);
                    break;
                case Heir.SON:
                case Heir.GRAND_SON:
                case Heir.DAUGHTER:
                case Heir.GRAND_DAUGHTER:
                case Heir.GRAND_GRAND_SON:
                case Heir.GRAND_GRAND_DAUGHTER:
                    childs.add(heir);
                    break;
                case Heir.FULL_PATERNAL_UNCLE:
                case Heir.PATERNAL_PATERNAL_UNCLE:
                case Heir.FULL_COUSIN:
                case Heir.FULL_COUSINS_SON:
                case Heir.FULL_COUSINS_GRANDSON:
                case Heir.PATERNAL_COUSIN:
                case Heir.PATERNAL_COUSINS_SON:
                case Heir.PATERNAL_COUSINS_GRANDSON:
                    uncleAndChilds.add(heir);
            }
        }

        if(spouse.size() > 0 ) {
            groups.add(spouse);
            groupsNames.add(R.string.spouseTitle);
        }
        if(parents.size() > 0) {
            groups.add(parents);
            groupsNames.add(R.string.parentsTitle);
        }
        if(childs.size() > 0) {
            groups.add(childs);
            groupsNames.add(R.string.childsTitle);
        }
        if(siblings.size()>0) {
            groups.add(siblings);
            groupsNames.add(R.string.siblingsTitle);
        }
        if(uncleAndChilds.size() > 0) {
            groups.add(uncleAndChilds);
            groupsNames.add(R.string.unclesChildsTitle);
        }
    }


    public Heir getHeirInGroup(int group, int child){
        return groups.get(group).get(child);
        /*if(group==0)
            return groups.get(group).get(child);
        else if(group==1)
            return groups.get(group).get(child);
        else if(group==2)
            return groups.get(group).get(child);
        else if(group==3)
            return groups.get(group).get(child);

        return null;*/
    }
}
