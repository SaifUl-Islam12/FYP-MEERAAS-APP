package com.jbeans.model;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class Wealth implements Distributable {

    private String name;
    private Map<String, Heir> heirs = null;
    private Set<Heir> asabaat = null;
    private double wealth = 0.0;
    private double totalPartsForAsabaat = 0;


    public Wealth(String name) {
        super();
        this.setName(name);
        this.setHeirs(new HashMap<String, Heir>());
        this.setAsabaat(new HashSet());
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    public double getTotalPartsForAsabaat() {
        return totalPartsForAsabaat;
    }

    public void setTotalPartsForAsabaat(double totalPartsForAsabaat) {
        this.totalPartsForAsabaat = totalPartsForAsabaat;
    }
    public void distributeAmongHeirs(double totalParts) {
        for (Heir heir : this.heirs.values()) {
            heir.setProportion(heir.calculateProportion(this, totalParts));
        }
    }

    public Map<String, Heir> getHeirs() {
        return heirs;
    }

    public void setHeirs(Map<String, Heir> heirs) {
        this.heirs = heirs;
    }

    public void addHeir(String relation, Heir heir) {
        this.heirs.put(relation, heir);
    }

    public Heir getHeir(String relation) {
        return this.heirs.get(relation);
    }

    public Set<Heir> getAsabaat() {
        return asabaat;
    }
    
    public void setWealth(double wealth){
        this.wealth = wealth;
    }
    
    public double getWealth(){
        return this.wealth;
    }

    public void setAsabaat(Set<Heir> asabaat) {
        this.asabaat = asabaat;
    }

    public int countHeirByRelation(String relation) {
        return heirs.get(relation) == null ? 0 : heirs.get(relation).getCount();
    }

    public int countChildrens() {
        return this.countHeirByRelation(Heir.SON) + this.countHeirByRelation(Heir.DAUGHTER);
    }

    public int countGrandChildrens() {
        return this.countHeirByRelation(Heir.GRAND_SON) + this.countHeirByRelation(Heir.GRAND_DAUGHTER);
    }

    public void addSons(int count) {
        if(count == 0)
            return;
        Heir heir = new Son(Heir.SON);
        heir.setCount(count);
        this.heirs.put(Heir.SON, heir);
    }

    public void addGrandSons(int count) {
        if(count == 0)
            return;
        Heir heir = new GrandSon(Heir.GRAND_SON);
        heir.setCount(count);
        this.heirs.put(Heir.GRAND_SON, heir);
    }

    public void addDaughters(int count) {
        if(count == 0)
            return;
        Heir heir = new Daughter(Heir.DAUGHTER);
        heir.setCount(count);
        this.heirs.put(Heir.DAUGHTER, heir);
    }

    public void addGrandDaughters(int count) {
        if(count == 0)
            return;
        Heir heir = new GrandDaughter(Heir.GRAND_DAUGHTER);
        heir.setCount(count);
        this.heirs.put(Heir.GRAND_DAUGHTER, heir);
    }

    public void addFather() {
        Heir heir = new Father(Heir.FATHER);
        this.heirs.put(Heir.FATHER, heir);
    }

    public void addPaternalGrandFather() {
        Heir heir = new PaternalGrandFather(Heir.PATERNAL_GRAND_FATHER);
        this.heirs.put(Heir.PATERNAL_GRAND_FATHER, heir);
    }

    public void addMother() {
        Heir heir = new Mother(Heir.MOTHER);
        this.heirs.put(Heir.MOTHER, heir);
    }

    public void addRealBrother(int count) {
        if(count == 0)
            return;
        Heir heir = new FullBrother(Heir.REAL_BROTHER);
        heir.setCount(count);
        this.heirs.put(Heir.REAL_BROTHER, heir);
    }

    public void addRealSister(int count) {
        if(count == 0)
            return;
        Heir heir = new FullSister(Heir.REAL_SISTER);
        heir.setCount(count);
        this.heirs.put(Heir.REAL_SISTER, heir);
    }

    public void addWives(int count) {
        if(count == 0)
            return;
        Heir heir = new Wife(Heir.WIFE);
        heir.setCount(count);
        this.heirs.put(Heir.WIFE, heir);
    }

    public void addHusband() {
        Heir heir = new Husband(Heir.HUSBAND);
        heir.setCount(1);
        this.heirs.put(Heir.HUSBAND, heir);
    }

    public void addMaternalGrandMother() {

        Heir heir = new MaternalGrandMother(Heir.MATERNAL_GRAND_MOTHER);
        this.heirs.put(Heir.MATERNAL_GRAND_MOTHER, heir);
    }

    public void addPaternalGrandMother() {
        Heir heir = new PaternalGrandMother(Heir.PATERNAL_GRAND_MOTHER);
        this.heirs.put(Heir.PATERNAL_GRAND_MOTHER, heir);
    }

    /**
     * Counts all kinds of brothers and siters i-e real plus half brothers
     *
     * @return number of Brothers and Sisters including half brothers and half
     * sisters
     */
    public int countAllBrothersAndSisters() {
        return countHeirByRelation(Heir.REAL_BROTHER) + countHeirByRelation(Heir.REAL_SISTER)
                + countHeirByRelation(Heir.PATERNAL_HALF_BROTHER) + countHeirByRelation(Heir.PATERNAL_HALF_SISTER)
                + countHeirByRelation(Heir.MATERNAL_HALF_BROTHER) + countHeirByRelation(Heir.MATERNAL_HALF_SISTER);
    }

    public void addMaternalGrandGrandMother() {
        Heir mggm = new MaternalGrandGrandMother(Heir.MATERNAL_GRAND_GRAND_MOTHER);
        this.heirs.put(Heir.MATERNAL_GRAND_GRAND_MOTHER, mggm);
    }

    public void addPaternalGrandGrandFather() {
        Heir pggf = new PaternalGrandGrandFather(Heir.PATERNAL_GRAND_GRAND_FATHER);
        this.heirs.put(Heir.PATERNAL_GRAND_GRAND_FATHER, pggf);
    }

    public void addPaternalGrandGrandMother() {
        Heir pggm = new PaternalGrandGrandMother(Heir.PATERNAL_GRAND_GRAND_MOTHER);
        this.heirs.put(Heir.PATERNAL_GRAND_GRAND_MOTHER, pggm);
    }

    public void addMaternalHalfBrother(Integer count) {
        if(count == 0)
            return;
        Heir mhb = new MaternalHalfBrother(Heir.MATERNAL_HALF_BROTHER);
        mhb.setCount(count);
        this.heirs.put(Heir.MATERNAL_HALF_BROTHER, mhb);
    }

    public void addMaternalHalfSister(Integer count) {
        if(count == 0)
            return;
        Heir mhb = new MaternalHalfSister(Heir.MATERNAL_HALF_SISTER);
        mhb.setCount(count);
        this.heirs.put(Heir.MATERNAL_HALF_SISTER, mhb);
    }

    public void addPaternalHalfBrother(Integer count) {
        if(count == 0)
            return;
        Heir mhb = new PaternalHalfBrother(Heir.PATERNAL_HALF_BROTHER);
        mhb.setCount(count);
        this.heirs.put(Heir.PATERNAL_HALF_BROTHER, mhb);
    }

    public void addPaternalHalfSister(Integer count) {
        if(count == 0)
            return;
        Heir mhb = new PaternalHalfSister(Heir.PATERNAL_HALF_SISTER);
        mhb.setCount(count);
        this.heirs.put(Heir.PATERNAL_HALF_SISTER, mhb);
    }

    public void solveAsabaat(double totalParts) {
        double remainingParts = totalParts;
        double partsAlreadyDistributed = 0;
        for (Heir heir : this.heirs.values()) {
            partsAlreadyDistributed += heir.getProportion();
            remainingParts -= heir.getProportion();
        }
        remainingParts = totalParts - partsAlreadyDistributed;

        double totalPartsForAsabaat = 0;
        for(Heir asaba:asabaat){
            totalPartsForAsabaat += asaba.getPartsIfAsaba();
        }

        Iterator<Heir> iterator = asabaat.iterator();
        while (iterator.hasNext()) {
            Heir asaba = iterator.next();
//            double parts = 1 * asaba.getCount();
//            if (asaba.getName().equals(Heir.SON) || asaba.getName().equals(Heir.GRAND_SON)
//                    || asaba.getName().equals(Heir.REAL_BROTHER) || asaba.getName().equals(Heir.PATERNAL_HALF_BROTHER)
//                    ) {
//                parts = 2 * asaba.getCount();
//            }
            
           // asaba.setProportion(parts/totalPartsForAsabaat * remainingParts);
            asaba.setProportion(asaba.getPartsIfAsaba()/totalPartsForAsabaat * remainingParts);
        }
    }

    public void addFullUncles(Integer count) {
        if(count == 0)
            return;
        Heir mhb = new FullPaternalUncle(Heir.FULL_PATERNAL_UNCLE);
        mhb.setCount(count);
        this.heirs.put(Heir.FULL_PATERNAL_UNCLE, mhb);
    }

    public void addPaternalPaternalUncles(Integer count) {
        if(count == 0)
            return;
        Heir mhb = new FullPaternalUncle(Heir.PATERNAL_PATERNAL_UNCLE);
        mhb.setCount(count);
        this.heirs.put(Heir.PATERNAL_PATERNAL_UNCLE, mhb);
    }

    public void addFullCousins(Integer count) {
        if(count == 0)
            return;
        Heir mhb = new FullCousin(Heir.FULL_COUSIN);
        mhb.setCount(count);
        this.heirs.put(Heir.FULL_COUSIN, mhb);
    }

    public void addFullCousinsSons(Integer count) {
        if(count == 0)
            return;
        Heir mhb = new FullCousinsSon(Heir.FULL_COUSINS_SON);
        mhb.setCount(count);
        this.heirs.put(Heir.FULL_COUSINS_SON, mhb);
    }

    public void addFullCousinsSonsSons(Integer count) {
        if(count == 0)
            return;
        Heir mhb = new FullCousinsGrandSon(Heir.FULL_COUSINS_GRANDSON);
        mhb.setCount(count);
        this.heirs.put(Heir.FULL_COUSINS_GRANDSON, mhb);
    }

    public void addPaternalCousins(Integer count) {
        if(count == 0)
            return;
        Heir mhb = new PaternalCousin(Heir.PATERNAL_COUSIN);
        mhb.setCount(count);
        this.heirs.put(Heir.PATERNAL_COUSIN, mhb);
    }

    public void addPaternalCousinsSons(Integer count) {
        if(count == 0)
            return;
        Heir mhb = new PaternalCousinsSon(Heir.PATERNAL_COUSINS_SON);
        mhb.setCount(count);
        this.heirs.put(Heir.PATERNAL_COUSINS_SON, mhb);
    }

    public void addPaternalCousinsSonsSons(Integer count) {
        if(count == 0)
            return;
        Heir mhb = new PaternalCousinsGrandSon(Heir.PATERNAL_COUSINS_GRANDSON);
        mhb.setCount(count);
        this.heirs.put(Heir.PATERNAL_COUSINS_GRANDSON, mhb);
    }

    public void addFullNephews(Integer count) {
        if(count == 0)
            return;
        Heir mhb = new FullNephew(Heir.FULL_NEPHEW);
        mhb.setCount(count);
        this.heirs.put(Heir.FULL_NEPHEW, mhb);
    }

    public void addFullNephewsSons(Integer count) {
        if(count == 0)
            return;
        Heir mhb = new FullNephewsSon(Heir.FULL_NEPHEWS_SON);
        mhb.setCount(count);
        this.heirs.put(Heir.FULL_NEPHEWS_SON, mhb);
    }

    public void addPaternalNephews(Integer count) {
        if(count == 0)
            return;
        Heir mhb = new PaternalNephew(Heir.PATERNAL_NEPHEW);
        mhb.setCount(count);
        this.heirs.put(Heir.PATERNAL_NEPHEW, mhb);
    }

    public void addPaternalNephewsSons(Integer count) {
        if(count == 0)
            return;
        Heir mhb = new PaternalNephewsSon(Heir.PATERNAL_NEPHEWS_SON);
        mhb.setCount(count);
        this.heirs.put(Heir.PATERNAL_NEPHEWS_SON, mhb);
    }

}
