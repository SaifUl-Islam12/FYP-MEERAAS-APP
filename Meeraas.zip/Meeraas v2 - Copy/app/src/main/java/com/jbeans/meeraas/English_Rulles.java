package com.jbeans.meeraas;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.widget.TextView;

public class English_Rulles extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_english__rulles);
        String rules =")\tHusband [AnNisa 4:12] \n" +
                "   a.\tGets 1/2 \n" +
                "      i.\tDeceased does not have any offspring \n" +
                "   b.\tGets 1/4 \n" +
                "      i.\tDeceased has offspring \n" +
                "\n" +
                "2)\tWife (Divided equally among all wives) [AnNisa 4:12] \n" +
                "   a.\tGets 1/4 \n" +
                "      i.\tDeceased does not have any offspring \n" +
                "   b.\tGets 1/8 \n" +
                "      i.\tDeceased has offspring \n" +
                "\n" +
                "3)\tDaughter (Divided equally among all daughters) \n" +
                "   a.\tGets 1/2 [AnNisa 4:11] \n" +
                "      i.\tDeceased has only 1 daughter, and [AnNisa 4:11] \n" +
                "      ii.\tDeceased does not have any sons [AnNisa 4:11] \n" +
                "   b.\tGets 2/3 [AnNisa 4:11] \n" +
                "      i.\tDeceased has multiple daughters, and [AnNisa 4:11] \n" +
                "      ii.\tDeceased does not have any sons [AnNisa 4:11] \n" +
                "\n" +
                "4)\tGrand Daughter (from son only) \n" +
                "   a.\tGets 1/2 \n" +
                "      i.\tDeceased has only 1 Grand daughter from a son \n" +
                "      ii.\tDeceased does not have a son or a daughter \n" +
                "      iii.\tDeceased does not have a Grandson from a son \n" +
                "   b.\tGets 2/3 \n" +
                "      i.\tDeceased has multiple Granddaughters from a son\n" +
                "      ii.\tDeceased does not have a son or a daughter\n" +
                "      iii.\tDeceased does not have a Grandson from a son \n" +
                "   c.\tGets 1/6 (H1) \n" +
                "      i.\tDeceased has just one daughter \n" +
                "      ii.\tDeceased does not have a son \n" +
                "      iii.\tDeceased does not have a Grandson from a son \n" +
                "\n" +
                "5)\tFather [AnNisa 4:11] \n" +
                "   a.\tGets 1/6 \n" +
                "      i.\tDeceased has offspring \n" +
                "\n" +
                "6)\tMother [AnNisa 4:11] \n" +
                "   a.\tGets 1/3 \n" +
                "      i.\tDeceased does not have any offspring, and\n" +
                "      ii.\tDeceased does not have multiple siblings (full, paternal, maternal) \n" +
                "   b.\tGets 1/6 \n" +
                "      i.\tDeceased has offspring, or \n" +
                "      ii.\tDeceased has multiple siblings (full, paternal, maternal) \n" +
                "\n" +
                "7)\tPaternal Grand Father \n" +
                "   a.\tGets 1/6 \n" +
                "      i.\tDeceased does not have a father \n" +
                "      ii.\tDeceased has offspring \n" +
                "\n" +
                "8)\tPaternal Grand Mother \n" +
                "   a.\tGets 1/6 \n" +
                "      i.\tDeceased does not have a mother \n" +
                "      ii.\tDeceased does not have a father \n" +
                "      iii.\tDeceased does not have a maternal grandmother\n" +
                "   b.\tGets 1/12 \n" +
                "   i.\tDeceased does not have a mother \n" +
                "   ii.\tDeceased does not have a father \n" +
                "   iii.\tDeceased has a maternal grandmother \n" +
                "\n" +
                "9)\tMaternal Grand Mother \n" +
                "   a.\tGets 1/6 \n" +
                "      i.\tDeceased does not have a mother \n" +
                "   b.\tGets 1/12 \n" +
                "      i.\tDeceased does not have a mother \n" +
                "      ii.\tDeceased does not have a father \n" +
                "      iii.\tDeceased has a paternal grandmother \n" +
                "\n" +
                "10)\tFull Sister \n" +
                "   a.\tGets ½ [AnNisa 4:176] \n" +
                "      i.\tDeceased has only 1 full sister \n" +
                "      ii.\tDeceased does not have any offspring \n" +
                "      iii.\tDeceased does not have any male paternal ancestor \n" +
                "      iv.\tDeceased does not have any full brother \n" +
                "   b.\tGets 2/3 [AnNisa 4:176] \n" +
                "      i.\tDeceased has multiple full sisters \n" +
                "      ii.\tDeceased does not have any offspring \n" +
                "      iii.\tDeceased does not have any male paternal ancestor \n" +
                "      iv.\tDeceased does not have any full brother \n" +
                "\n" +
                "11)\tPaternal Sister \n" +
                "   a.\tGets 1/2 \n" +
                "      i.\tDeceased has only 1 paternal sister \n" +
                "      ii.\tDeceased does not have any offspring \n" +
                "      iii.\tDeceased does not have any male paternal ancestor \n" +
                "      iv.\tDeceased does not have any full brother, full sister or paternal brother \n" +
                "   b.\tGets 2/3 \n" +
                "      i.\tDeceased has multiple paternal sisters \n" +
                "      ii.\tDeceased does not have any offspring \n" +
                "      iii.\tDeceased does not have any male paternal ancestor \n" +
                "      iv.\tDeceased does not have any full brother, full sister or paternal brother \n" +
                "   c.\tGets 1/6 \n" +
                "      i.\tDeceased has just 1 full sister \n" +
                "      ii.\tDeceased does not have any offspring \n" +
                "      iii.\tDeceased does not have any male paternal ancestor \n" +
                "      iv.\tDeceased does not have any full brother or paternal brother \n" +
                "\n" +
                "12)\tMaternal Sibling [AnNisa 4:12] \n" +
                "   a.\tGets 1/6 \n" +
                "      i.\tDeceased has only 1 maternal sibling \n" +
                "      ii.\tDeceased does not have any male offspring \n" +
                "      iii.\tDeceased does not have any male paternal ancestors \n" +
                "   b.\tGets 1/3 \n" +
                "      i.\tDeceased has multiple maternal siblings \n" +
                "      ii.\tDeceased does not have any male offspring \n" +
                "      iii.\tDeceased does not have any male paternal ancestors Residual Shares (H2) \n" +
                "\n" +
                "13)\tBlocking Rules \n" +
                "   a. Son blocks Paternal Grandson, Paternal Granddaughter, Full brother, Full sister, Paternal brother, Paternal sister, Maternal Brother, Maternal sister, Full Nephew, Paternal Nephew, Full Nephew’s son, Paternal Nephew’s son, Full paternal Uncle, Paternal paternal uncle, Full cousin, Paternal Cousin, Full cousin’s son, Paternal Cousin’s son, Full cousin’s son’s son, Paternal Cousin’s son’s son \n" +
                "   b. Grandson blocks Full brother, Full sister, Paternal brother, Paternal sister, Maternal Brother, Maternal sister, Full Nephew, Paternal Nephew, Full Nephew’s son, Paternal Nephew’s son, Full paternal Uncle, Paternal paternal uncle, Full cousin, Paternal Cousin, Full cousin’s son, Paternal Cousin’s son, Full cousin’s son’s son, Paternal Cousin’s son’s son\n" +
                "   c. Father blocks Paternal Grandfather, Paternal Grandmother, Full brother, Full sister, Paternal brother, Paternal sister, Maternal Brother, Maternal sister, Full Nephew, Paternal Nephew, Full Nephew’s son, Paternal Nephew’s son, Full paternal Uncle, Paternal paternal uncle, Full cousin, Paternal Cousin, Full cousin’s son, Paternal Cousin’s son, Full cousin’s son’s son, Paternal Cousin’s son’s son \n" +
                "   d.\tMother blocks Paternal Grandmother, Maternal Grandmother \n" +
                "   e. Grandfather blocks Full Nephew, Paternal Nephew, Full Nephew’s son, Paternal Nephew’s son, Full paternal Uncle, Paternal paternal uncle, Full cousin, Paternal Cousin, Full cousin’s son, Paternal Cousin’s son, Full cousin’s son’s son, Paternal Cousin’s son’s son\n" +
                "   f. Full brother blocks Paternal brother, Paternal sister, Full Nephew, Paternal Nephew, Full Nephew’s son, Paternal Nephew’s son, Full paternal Uncle, Paternal paternal uncle, Full cousin, Paternal Cousin, Full cousin’s son, Paternal Cousin’s son, Full cousin’s son’s son, Paternal Cousin’s son’s son \n" +
                "   g.\tFull sister blocks Paternal brother, Paternal sister, ,Full Nephew, Paternal Nephew, Full Nephew’s son, Paternal Nephew’s son, Full paternal Uncle, Paternal paternal uncle, Full cousin, Paternal Cousin, Full cousin’s son, Paternal Cousin’s son, Full cousin’s son’s son, Paternal Cousin’s son’s son(can block only if the deceased has at least 1 female offspring, otherwise stuck in 2/3 zone)\n" +
                "   h. Paternal brother blocks Full Nephew, Paternal Nephew, Full Nephew’s son, Paternal Nephew’s son, Full paternal Uncle, Paternal paternal uncle, Full cousin, Paternal Cousin, Full cousin’s son, Paternal Cousin’s son, Full cousin’s son’s son, Paternal Cousin’s son’s son \n" +
                "   i.\tPaternal sister blocks Full Nephew, Paternal Nephew, Full Nephew’s son, Paternal Nephew’s son, Full paternal Uncle, Paternal paternal uncle, Full cousin, Paternal Cousin, Full cousin’s son, Paternal Cousin’s son, Full cousin’s son’s son, Paternal Cousin’s son’s son(can block only if the deceased has either at least 1 female offspring or at least 2 sisters, otherwise stuck in 2/3 zone) \n" +
                "   j.\tFull Nephew blocks Paternal Nephew, Full Nephew’s son, Paternal Nephew’s son, Full paternal Uncle, Paternal paternal uncle, Full cousin, Paternal Cousin, Full cousin’s son, Paternal Cousin’s son, Full cousin’s son’s son, Paternal Cousin’s son’s son \n" +
                "   k.\tPaternal Nephew blocks Full Nephew’s son, Paternal Nephew’s son, Full paternal Uncle, Paternal paternal uncle, Full cousin, Paternal Cousin, Full cousin’s son, Paternal Cousin’s son, Full cousin’s son’s son, Paternal Cousin’s son’s son \n" +
                "   l.\tFull Nephew’s son blocks Paternal Nephew’s son, Full paternal Uncle, Paternal paternal uncle, Full cousin, Paternal Cousin, Full cousin’s son, Paternal Cousin’s son, Full cousin’s son’s son, Paternal Cousin’s son’s son \n" +
                "   m.\tPaternal Nephew’s son blocks Full paternal Uncle, Paternal paternal uncle, Full cousin, Paternal Cousin, Full cousin’s son, Paternal Cousin’s son, Full cousin’s son’s son, Paternal Cousin’s son’s son \n" +
                "   n.\tFull paternal Uncle blocks Paternal paternal uncle, Full cousin, Paternal Cousin, Full cousin’s son, Paternal Cousin’s son, Full cousin’s son’s son, Paternal Cousin’s son’s son \n" +
                "   o.\tPaternal paternal uncle blocks Full cousin, Paternal Cousin, Full cousin’s son, Paternal Cousin’s son, Full cousin’s son’s son, Paternal Cousin’s son’s son \n" +
                "   p.\tFull cousin blocks Paternal Cousin, Full cousin’s son, Paternal Cousin’s son, Full cousin’s son’s son, Paternal Cousin’s son’s son \n" +
                "   q.\tPaternal Cousin blocks Full cousin’s son, Paternal Cousin’s son, Full cousin’s son’s son, Paternal Cousin’s son’s son \n" +
                "   r.\tFull cousin’s son blocks Paternal Cousin’s son, Full cousin’s son’s son, Paternal Cousin’s son’s son \n" +
                "   s.\tPaternal Cousin’s son blocks Full cousin’s son’s son, Paternal Cousin’s son’s son \n" +
                "   t.\tFull cousin’s son’s son blocks Paternal Cousin’s son’s son \n" +
                "\n" +
                "14)\tTasib ranking in order \n" +
                "1)\tSon, daughter 2)\tPaternal Grandson, paternal Granddaughter 3)\tFather 4)\tFull Brother, Full sister (Kalaalah starts here) 5) Paternal Brother, Paternal Sister 6)\tPaternal Grandfather 7)\tFull brother’s son 8)\tPaternal brother’s son 9)\tFull brother’s son’s son 10)\tPaternal brother son’s son 11)\tPaternal uncle (father’s full brother) 12)\tPaternal paternal uncle (father’s paternal brother) 13)\tPaternal uncle’s son (father’s brother’s son) 14)\tPaternal paternal uncle’s son (father’s paternal brother’s son) 15)\tPaternal uncle’s son’s son (father’s brother’s son’ s son) 16)\tPaternal paternal uncle’s son’s son (father’s paternal brother’s son’s son) 17) Paternal uncle’s son’s son’s son (father’s brother’s son’ s son’s son) 18)\tPaternal paternal uncle’s son’s son’s son (father’s paternal brother’s son’s son’s son) 19)\tEmancipator 20)\tEmancipator’s independent Aaseebs \n" +
                "\n" +
                "15)\tA male & female of the same class receive shares with the ration of 2:1 [AnNisa 4:11], [AnNisa 4:176]. The following conditions should be met. \n" +
                "   a.\tMale & female are of the same class \n" +
                "   b.\tThis rule applies during the distribution of residual shares, and not the distribution of prescribed shares \n" +
                "   c.\tThis rule doesn’t apply to maternal siblings. They are either ways given from prescribed shares \n" +
                "\n" +
                "16)\tIf an heir is given the prescribed share, he/she drops from Ta’seeb if there are other Aaseebs qualified for inheritance a. Father is an exception to this rule \n" +
                "\n" +
                "17)\tA father, or a grandfather, can never be cutoff by the heirs with prescribed shares. \n" +
                "\n" +
                "\n" +
                "18)\tIn the ‘Awal case, when the total is more than 1, all shares should be reduced proportionately so that the total shares is 1 \n" +
                "   a.\tIn case of Awal, and in the presence of Grandfather, sisters will be removed from the 2/3rd zone. Grandfather & sisters then will divide in the ratio of 2:1. (Disturbing Case) ) \n" +
                "\n" +
                "19) In Radd case, when the total is less than 1, all shares, except the shares of the spouse, should be increased proportionately so that the total share is 1. The spouse shares are strictly fixed. They cannot be increased unless no far relatives are found. \n" +
                "\n" +
                "\n" +
                "20)\tIf husband is also a paternal cousin (or his offspring), or an emancipator (or his relative), he should be treated as two individuals and distribution should be made for each (if qualified) \n" +
                "\n" +
                "21)\tIf the deceased left behind a spouse, a father and a mother, but no offspring & multiple siblings, Umar’s calculations need to be applied. (Umar’s Fatawa) \n" +
                "   a.\tParents will not get their prescribed share \n" +
                "   b.\tParents will share the remainder with the 2:1 ratio for father & mother \n" +
                "   c.\tMultiple siblings can reduce mother’s share so Umar’s case will no longer be valid \n" +
                "\n" +
                "22)\tA full brother cannot receive less than the maternal brother \n" +
                "   a.\tFull brothers should share equally with the maternal siblings. Effectively, full brothers are treated as maternal siblings. \n" +
                "   b.\tThis doesn’t apply to paternal brother (becoming maternal brother) \n" +
                "\n" +
                "23)\tIf the deceased did not leave behind a father or offspring, but left behind at least grandfather & siblings, he has a special case \n" +
                "   a.\tA=1/6 of the estate \n" +
                "   b.\tB=1/3 of the remainder of shares \n" +
                "   c.\tC=Treat grandfather like a brother and divide the shares equally among them \n" +
                "   d.\tThe grandfather will be given the maximum of A, B and C \n" +
                "   e.\tIf the grandfather’s share is causing the total shares to exceed 1, then the regular share of 1/6 will be given and the max of A, B, C rule will be ignored \n" +
                "   f.\tIf the fractions sum exceeds 1, Awal should be applied; Grandfather’s share is not Ta’seeb in this case. \n" +
                "   g.\tDuring this calculation, Full Sister & paternal sister ‘s share should be excluded (if they are in 2/3rd zone) \n" +
                "\n" +
                "24)\tIf the deceased did not leave behind a father or offspring or brother, but left behind at least a grandfather and a sister. If a sister gets more than grandfather, then the shares should be readjusted \n" +
                "   a.\tDiscard the prescribed share of the sister \n" +
                "   b.\tSister & grandfather should share the remainder of estate with the ratio 1:2 Far Relatives \n" +
                "\n" +
                "25)\tDivide the inheritance to non-standard far relatives replacing themselves with the link they are attached to who is qualified for the inheritance..\n" +
                "\n" +
                "26)\tIf there is still a remainder, then the remaining can now be given to the spouse if alive \n" +
                "\n" +
                "27) If the deceased has obsoletely no relatives, the Islamic state takes the entire estate. \n" +
                "\n" +
                "28)\tIn case of female heirs, the inheritance stops at them and does not move on to their children as in case of male heirs. \n" +
                "\n" +
                "29)\tIn the absence of immediate children, grandchildren replace them as heirs \n" +
                "\n" +
                "30)\tThe 2/3 zone \n" +
                "   a.\tCertain female relatives can get into this zone \n" +
                "   b.\tThe 4 possible relatives in this zone are – daughter, paternal granddaughter, full sister, paternal sister \n" +
                "   c.\tWhen a heir is inside this zone, she cannot block any body \n" +
                "   d.\tThe male sibling of the same class can get her out of the 2/3 zone \n" +
                "      i.\tSon for the daughter\n" +
                "      ii.\tPaternal grandson for the paternal granddaughter \n" +
                "      iii.\tFull brother for the full sister \n" +
                "      iv.\tPaternal brother for the paternal sister \n" +
                "   e.\tFemale offspring can never be together with female siblings in the 2/3 zone. The female offspring can get the female siblings out of the 2/3 zone \n" +
                "   f.\tDaughter & granddaughter cannot be given the same share when in 2/3 zone. Same applies for full sister & paternal sister. One is given ½ & the other is given 1/6. \n" +
                "   g.\tFull brother can get the paternal sister out of 2/3 zone, actually completely blocks her. \n" +
                "\n" +
                "31)\tThe 2/3 fraction is either for daughter-granddaughter, or, full sister-paternal sister. The 2/3 can never be shared between female offspring & female siblings \n" +
                "\n" +
                "32)\tMaternal siblings can reduce mother’s share \n" +
                "\n" +
                "33)\tMaternal siblings do not have 1:2 male female ratio \n" +
                "\n" +
                "34)\tFather blocks full siblings, paternal siblings, and maternal siblings \n" +
                "\n" +
                "35)\tFollowing relatives can never be blocked \n" +
                "   •\tHusband \n" +
                "   •\tWife \n" +
                "   •\tFather \n" +
                "   •\tMother \n" +
                "   •\tSon \n" +
                "   •\tDaughter \n" +
                "\n" +
                "36)\tSpouse can neither be blocked, nor can they block any body \n" +
                "\n" +
                "37)\tSpouse share can never be increased, even if there are no more standard heirs left. The far relatives are given priority first before increasing spouse’s share are \n" +
                "\n" +
                "38)\tRole promotion when the person is not alive \n" +
                "   •\tGrandfather becomes a father \n" +
                "   •\tPaternal grandmother becomes a mother \n" +
                "   •\tGranddaughter become a daughter \n" +
                "   •\tSister becomes a daughter \n" +
                "   •\tPaternal sister becomes a daughter \n" +
                "\n" +
                "39)\tMaternal grandfather (mother’s father) is blocked from inheritance. His both male & female ancestors are also blocked. This is different from maternal grandmother (mother’s mother). She gets the inheritance. Also, her female ancestors can also get inheritance, but not the male ancestors. \n" +
                "\n" +
                "40)\tThe only female chain that continues indefinitely is mother’s mother’s mother’s …. \n" +
                "\n" +
                "41)\tThere is a difference of opinion on father blocking the father’s mother. However, all agree that a mother can block father’s mother. \n" +
                "\n" +
                "42)\tThere is some difference of opinion on grandfather blocking the siblings \n" +
                "\n" +
                "43)\tFollowing relatives are not qualified for Ta’seeb \n" +
                "   •\tMother \n" +
                "   •\tPaternal grandmother \n" +
                "   •\tMaternal grandmother \n" +
                "   •\tHusband \n" +
                "   •\tWife \n" +
                "   •\tMaternal Brother \n" +
                "   •\tMaternal Sister \n" +
                "\n" +
                "44)\tJoint Ta’seebs are possible only for the following casess\n" +
                "   •\tSon & daughter\n" +
                "   •\tGrandson & Grand daughter\n" +
                "   •\tFull brother & full sister \n" +
                "   •\tPaternal brother & paternal sister\n" +
                " paternal ancestors Residual Shares (H2) 13)\tBlocking Rules \n" +
                "   a. Son blocks Paternal Grandson, Paternal Granddaughter, Full brother, Full sister, Paternal brother, Paternal sister, Maternal Brother, Maternal sister, Full Nephew, Paternal Nephew, Full Nephew’s son, Paternal Nephew’s son, Full paternal Uncle, Paternal paternal uncle, Full cousin, Paternal Cousin, Full cousin’s son, Paternal Cousin’s son, Full cousin’s son’s son, Paternal Cousin’s son’s son \n" +
                "   b. Grandson blocks Full brother, Full sister, Paternal brother, Paternal sister, Maternal Brother, Maternal sister, Full Nephew, Paternal Nephew, Full Nephew’s son, Paternal Nephew’s son, Full paternal Uncle, Paternal paternal uncle, Full cousin, Paternal Cousin, Full cousin’s son, Paternal Cousin’s son, Full cousin’s son’s son, Paternal Cousin’s son’s son\n" +
                "   c. Father blocks Paternal Grandfather, Paternal Grandmother, Full brother, Full sister, Paternal brother, Paternal sister, Maternal Brother, Maternal sister, Full Nephew, Paternal Nephew, Full Nephew’s son, Paternal Nephew’s son, Full paternal Uncle, Paternal paternal uncle, Full cousin, Paternal Cousin, Full cousin’s son, Paternal Cousin’s son, Full cousin’s son’s son, Paternal Cousin’s son’s son \n" +
                "   d.\tMother blocks Paternal Grandmother, Maternal Grandmother \n" +
                "   e. Grandfather blocks Full Nephew, Paternal Nephew, Full Nephew’s son, Paternal Nephew’s son, Full paternal Uncle, Paternal paternal uncle, Full cousin, Paternal Cousin, Full cousin’s son, Paternal Cousin’s son, Full cousin’s son’s son, Paternal Cousin’s son’s son\n" +
                "   f. Full brother blocks Paternal brother, Paternal sister, Full Nephew, Paternal Nephew, Full Nephew’s son, Paternal Nephew’s son, Full paternal Uncle, Paternal paternal uncle, Full cousin, Paternal Cousin, Full cousin’s son, Paternal Cousin’s son, Full cousin’s son’s son, Paternal Cousin’s son’s son \n" +
                "   g.\tFull sister blocks Paternal brother, Paternal sister, ,Full Nephew, Paternal Nephew, Full Nephew’s son, Paternal Nephew’s son, Full paternal Uncle, Paternal paternal uncle, Full cousin, Paternal Cousin, Full cousin’s son, Paternal Cousin’s son, Full cousin’s son’s son, Paternal Cousin’s son’s son(can block only if the deceased has at least 1 female offspring, otherwise stuck in 2/3 zone)\n" +
                "   h. Paternal brother blocks Full Nephew, Paternal Nephew, Full Nephew’s son, Paternal Nephew’s son, Full paternal Uncle, Paternal paternal uncle, Full cousin, Paternal Cousin, Full cousin’s son, Paternal Cousin’s son, Full cousin’s son’s son, Paternal Cousin’s son’s son \n" +
                "   i.\tPaternal sister blocks Full Nephew, Paternal Nephew, Full Nephew’s son, Paternal Nephew’s son, Full paternal Uncle, Paternal paternal uncle, Full cousin, Paternal Cousin, Full cousin’s son, Paternal Cousin’s son, Full cousin’s son’s son, Paternal Cousin’s son’s son(can block only if the deceased has either at least 1 female offspring or at least 2 sisters, otherwise stuck in 2/3 zone) \n" +
                "   j.\tFull Nephew blocks Paternal Nephew, Full Nephew’s son, Paternal Nephew’s son, Full paternal Uncle, Paternal paternal uncle, Full cousin, Paternal Cousin, Full cousin’s son, Paternal Cousin’s son, Full cousin’s son’s son, Paternal Cousin’s son’s son \n" +
                "   k.\tPaternal Nephew blocks Full Nephew’s son, Paternal Nephew’s son, Full paternal Uncle, Paternal paternal uncle, Full cousin, Paternal Cousin, Full cousin’s son, Paternal Cousin’s son, Full cousin’s son’s son, Paternal Cousin’s son’s son \n" +
                "   l.\tFull Nephew’s son blocks Paternal Nephew’s son, Full paternal Uncle, Paternal paternal uncle, Full cousin, Paternal Cousin, Full cousin’s son, Paternal Cousin’s son, Full cousin’s son’s son, Paternal Cousin’s son’s son \n" +
                "   m.\tPaternal Nephew’s son blocks Full paternal Uncle, Paternal paternal uncle, Full cousin, Paternal Cousin, Full cousin’s son, Paternal Cousin’s son, Full cousin’s son’s son, Paternal Cousin’s son’s son \n" +
                "   n.\tFull paternal Uncle blocks Paternal paternal uncle, Full cousin, Paternal Cousin, Full cousin’s son, Paternal Cousin’s son, Full cousin’s son’s son, Paternal Cousin’s son’s son \n" +
                "   o.\tPaternal paternal uncle blocks Full cousin, Paternal Cousin, Full cousin’s son, Paternal Cousin’s son, Full cousin’s son’s son, Paternal Cousin’s son’s son \n" +
                "   p.\tFull cousin blocks Paternal Cousin, Full cousin’s son, Paternal Cousin’s son, Full cousin’s son’s son, Paternal Cousin’s son’s son \n" +
                "   q.\tPaternal Cousin blocks Full cousin’s son, Paternal Cousin’s son, Full cousin’s son’s son, Paternal Cousin’s son’s son \n" +
                "   r.\tFull cousin’s son blocks Paternal Cousin’s son, Full cousin’s son’s son, Paternal Cousin’s son’s son \n" +
                "   s.\tPaternal Cousin’s son blocks Full cousin’s son’s son, Paternal Cousin’s son’s son \n" +
                "   t.\tFull cousin’s son’s son blocks Paternal Cousin’s son’s son \n" +
                "\n" +
                "14)\tTasib ranking in order \n" +
                "1)\tSon, daughter 2)\tPaternal Grandson, paternal Granddaughter 3)\tFather 4)\tFull Brother, Full sister (Kalaalah starts here) 5) Paternal Brother, Paternal Sister 6)\tPaternal Grandfather 7)\tFull brother’s son 8)\tPaternal brother’s son 9)\tFull brother’s son’s son 10)\tPaternal brother son’s son 11)\tPaternal uncle (father’s full brother) 12)\tPaternal paternal uncle (father’s paternal brother) 13)\tPaternal uncle’s son (father’s brother’s son) 14)\tPaternal paternal uncle’s son (father’s paternal brother’s son) 15)\tPaternal uncle’s son’s son (father’s brother’s son’ s son) 16)\tPaternal paternal uncle’s son’s son (father’s paternal brother’s son’s son) 17) Paternal uncle’s son’s son’s son (father’s brother’s son’ s son’s son) 18)\tPaternal paternal uncle’s son’s son’s son (father’s paternal brother’s son’s son’s son) 19)\tEmancipator 20)\tEmancipator’s independent Aaseebs \n" +
                "\n" +
                "15)\tA male & female of the same class receive shares with the ration of 2:1 [AnNisa 4:11], [AnNisa 4:176]. The following conditions should be met. \n" +
                "   a.\tMale & female are of the same class \n" +
                "   b.\tThis rule applies during the distribution of residual shares, and not the distribution of prescribed shares \n" +
                "   c.\tThis rule doesn’t apply to maternal siblings. They are either ways given from prescribed shares \n" +
                "\n" +
                "16)\tIf an heir is given the prescribed share, he/she drops from Ta’seeb if there are other Aaseebs qualified for inheritance a. Father is an exception to this rule \n" +
                "\n" +
                "17)\tA father, or a grandfather, can never be cutoff by the heirs with prescribed shares. \n" +
                "\n" +
                "\n" +
                "18)\tIn the ‘Awal case, when the total is more than 1, all shares should be reduced proportionately so that the total shares is 1 \n" +
                "   a.\tIn case of Awal, and in the presence of Grandfather, sisters will be removed from the 2/3rd zone. Grandfather & sisters then will divide in the ratio of 2:1. (Disturbing Case) ) \n" +
                "\n" +
                "19) In Radd case, when the total is less than 1, all shares, except the shares of the spouse, should be increased proportionately so that the total share is 1. The spouse shares are strictly fixed. They cannot be increased unless no far relatives are found. \n" +
                "\n" +
                "\n" +
                "20)\tIf husband is also a paternal cousin (or his offspring), or an emancipator (or his relative), he should be treated as two individuals and distribution should be made for each (if qualified) \n" +
                "\n" +
                "21)\tIf the deceased left behind a spouse, a father and a mother, but no offspring & multiple siblings, Umar’s calculations need to be applied. (Umar’s Fatawa) \n" +
                "   a.\tParents will not get their prescribed share \n" +
                "   b.\tParents will share the remainder with the 2:1 ratio for father & mother \n" +
                "   c.\tMultiple siblings can reduce mother’s share so Umar’s case will no longer be valid \n" +
                "\n" +
                "22)\tA full brother cannot receive less than the maternal brother \n" +
                "   a.\tFull brothers should share equally with the maternal siblings. Effectively, full brothers are treated as maternal siblings. \n" +
                "   b.\tThis doesn’t apply to paternal brother (becoming maternal br 23)\tIf the deceased did not leave behind a father or offspring, but left behind at least grandfather & siblings, he has a special case \n" +
                "   a.\tA=1/6 of the estate \n" +
                "   b.\tB=1/3 of the remainder of shares \n" +
                "   c.\tC=Treat grandfather like a brother and divide the shares equally among them \n" +
                "   d.\tThe grandfather will be given the maximum of A, B and C \n" +
                "   e.\tIf the grandfather’s share is causing the total shares to exceed 1, then the regular share of 1/6 will be given and the max of A, B, C rule will be ignored \n" +
                "   f.\tIf the fractions sum exceeds 1, Awal should be applied; Grandfather’s share is not Ta’seeb in this case. \n" +
                "   g.\tDuring this calculation, Full Sister & paternal sister ‘s share should be excluded (if they are in 2/3rd zone) \n" +
                "\n" +
                "24)\tIf the deceased did not leave behind a father or offspring or brother, but left behind at least a grandfather and a sister. If a sister gets more than grandfather, then the shares should be readjusted \n" +
                "   a.\tDiscard the prescribed share of the sister \n" +
                "   b.\tSister & grandfather should share the remainder of estate with the ratio 1:2 Far Relatives \n" +
                "\n" +
                "25)\tDivide the inheritance to non-standard far relatives replacing themselves with the link they are attached to who is qualified for the inheritance..\n" +
                "\n" +
                "26)\tIf there is still a remainder, then the remaining can now be given to the spouse if alive \n" +
                "\n" +
                "27) If the deceased has obsoletely no relatives, the Islamic state takes the entire estate. \n" +
                "\n" +
                "28)\tIn case of female heirs, the inheritance stops at them and does not move on to their children as in case of male heirs. \n" +
                "\n" +
                "29)\tIn the absence of immediate children, grandchildren replace them as heirs \n" +
                "\n" +
                "30)\tThe 2/3 zone \n" +
                "   a.\tCertain female relatives can get into this zone \n" +
                "   b.\tThe 4 possible relatives in this zone are – daughter, paternal granddaughter, full sister, paternal sister \n" +
                "   c.\tWhen a heir is inside this zone, she cannot block any body \n" +
                "   d.\tThe male sibling of the same class can get her out of the 2/3 zone \n" +
                "      i.\tSon for the daughter\n" +
                "      ii.\tPaternal grandson for the paternal granddaughter \n" +
                "      iii.\tFull brother for the full sister \n" +
                "      iv.\tPaternal brother for the paternal sister \n" +
                "   e.\tFemale offspring can never be together with female siblings in the 2/3 zone. The female offspring can get the female siblings out of the 2/3 zone \n" +
                "   f.\tDaughter & granddaughter cannot be given the same share when in 2/3 zone. Same applies for full sister & paternal sister. One is given ½ & the other is given 1/6. \n" +
                "   g.\tFull brother can get the paternal sister out of 2/3 zone, actually completely blocks her. \n" +
                "\n" +
                "31)\tThe 2/3 fraction is either for daughter-granddaughter, or, full sister-paternal sister. The 2/3 can never be shared between female offspring & female siblings \n" +
                "\n" +
                "32)\tMaternal siblings can reduce mother’s share \n" +
                "\n" +
                "33)\tMaternal siblings do not have 1:2 male female ratio \n" +
                "\n" +
                "34)\tFather blocks full siblings, paternal siblings, and maternal siblings \n" +
                "\n" +
                "35)\tFollowing relatives can never be blocked \n" +
                "   •\tHusband \n" +
                "   •\tWife \n" +
                "   •\tFather \n" +
                "   •\tMother \n" +
                "   •\tSon \n" +
                "   •\tDaughter 36)\tSpouse can neither be blocked, nor can they block any body \n" +
                "\n" +
                "37)\tSpouse share can never be increased, even if there are no more standard heirs left. The far relatives are given priority first before increasing spouse’s share are \n" +
                "\n" +
                "38)\tRole promotion when the person is not alive \n" +
                "   •\tGrandfather becomes a father \n" +
                "   •\tPaternal grandmother becomes a mother \n" +
                "   •\tGranddaughter become a daughter \n" +
                "   •\tSister becomes a daughter \n" +
                "   •\tPaternal sister becomes a daughter \n" +
                "\n" +
                "39)\tMaternal grandfather (mother’s father) is blocked from inheritance. His both male & female ancestors are also blocked. This is different from maternal grandmother (mother’s mother). She gets the inheritance. Also, her female ancestors can also get inheritance, but not the male ancestors. \n" +
                "\n" +
                "40)\tThe only female chain that continues indefinitely is mother’s mother’s mother’s …. \n" +
                "\n" +
                "41)\tThere is a difference of opinion on father blocking the father’s mother. However, all agree that a mother can block father’s mother. \n" +
                "\n" +
                "42)\tThere is some difference of opinion on grandfather blocking the siblings \n" +
                "\n" +
                "43)\tFollowing relatives are not qualified for Ta’seeb \n" +
                "   •\tMother \n" +
                "   •\tPaternal grandmother \n" +
                "   •\tMaternal grandmother \n" +
                "   •\tHusband \n" +
                "   •\tWife \n" +
                "   •\tMaternal Brother \n" +
                "   •\tMaternal Sister \n" +
                "\n" +
                "44)\tJoint Ta’seebs are possible only for the following casess\n" +
                "   •\tSon & daughter\n" +
                "   •\tGrandson & Grand daughter\n" +
                "   •\tFull brother & full sister \n" +
                "   •\tPaternal brother & paternal sister";
        TextView textView = (TextView)findViewById(R.id.rulls_txt);
        textView.setText(rules.toString());
        textView.setMovementMethod(new ScrollingMovementMethod());
    }
}
