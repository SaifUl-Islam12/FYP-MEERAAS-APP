package com.jbeans.model;

import com.jbeans.meeraas.DATA;
import com.jbeans.meeraas.R;

public class MaternalGrandMother extends Heir{

	public MaternalGrandMother(String name) {
		super(name);

		if (DATA.getInstance().factor_value==99){
			setNameId(R.string.mgm);
		}
		else if (DATA.getInstance().factor_value==111){
			setNameId(R.string.u_mgm);
		}

		// TODO Auto-generated constructor stub
	}

	@Override
	double calculateProportion(Wealth deadPerson, double totalParts) {
		if(deadPerson.getHeir(MOTHER) == null){
                    if(deadPerson.getHeir(PATERNAL_GRAND_MOTHER) != null  && deadPerson.getHeir(FATHER) != null)
			return totalParts/12.0;
                    else
                        return totalParts/6.0;
                }else{
                    setCondition("mahjoob_reason_mother");
                    return 0 ;
                }		
	}

}
