package com.jbeans.model;

public interface Distributable {
	void distributeAmongHeirs(double totalParts);
}
