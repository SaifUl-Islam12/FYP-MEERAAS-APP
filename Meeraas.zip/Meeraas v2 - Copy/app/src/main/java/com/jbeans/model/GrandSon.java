package com.jbeans.model;

import com.jbeans.meeraas.DATA;
import com.jbeans.meeraas.R;

public class GrandSon extends Heir {

	public GrandSon(String name){
		super(name);
                this.partsIfAsaba = 2;

		if (DATA.getInstance().factor_value==99){
			setNameId(R.string.gs);

		}
		else if (DATA.getInstance().factor_value==111){
			setNameId(R.string.u_gs);

		}
	}
	
	@Override
	double calculateProportion(Wealth deadPerson, double totalParts) {
            if(deadPerson.countHeirByRelation(SON) != 0){
                setCondition("mahjoob_reason_son");
                return 0;
            }
            
		if(deadPerson.countHeirByRelation(SON) ==0 && deadPerson.countHeirByRelation(DAUGHTER) == 0){
                    setCondition("asaba_reason_noSon_noDaughter");
                    deadPerson.getAsabaat().add(this);
                    setAsaba(true);
		}
		return 0;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "GrandSon : " + getProportion() + (isAsaba() ? " + Asaba":"");
	}

}
