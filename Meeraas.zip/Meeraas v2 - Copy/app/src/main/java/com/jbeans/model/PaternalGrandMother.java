package com.jbeans.model;

import com.jbeans.meeraas.DATA;
import com.jbeans.meeraas.R;

public class PaternalGrandMother extends Heir {

    public PaternalGrandMother(String name) {
        super(name);

        if (DATA.getInstance().factor_value==99){
            setNameId(R.string.pgm);
        }
        else if (DATA.getInstance().factor_value==111){
            setNameId(R.string.u_pgm);
        }
        // TODO Auto-generated constructor stub
    }

    @Override
    double calculateProportion(Wealth deadPerson, double totalParts) {
        if (deadPerson.getHeir(FATHER) != null){
                    setCondition("mahjoob_reason_father");
                    return 0;
                }
        if(deadPerson.getHeir(MOTHER) != null){
            setCondition("mahjoob_reason_mother");
            return 0;
        
        }

        if (deadPerson.getHeir(MOTHER) == null && deadPerson.getHeir(FATHER) == null) {
            if (deadPerson.getHeir(MATERNAL_GRAND_MOTHER) != null) {
                return totalParts / 12.0;
            } else {
                return totalParts / 6.0;
            }
        }

        return 0;
    }

}
