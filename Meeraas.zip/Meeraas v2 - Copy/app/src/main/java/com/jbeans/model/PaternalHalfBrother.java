/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.jbeans.model;

import com.jbeans.meeraas.DATA;
import com.jbeans.meeraas.R;

/**
 *
 * @author Saeed
 */
public class PaternalHalfBrother extends Heir{

    public PaternalHalfBrother(String name) {
        super(name);
        this.partsIfAsaba = 2;

        if (DATA.getInstance().factor_value==99){
            setNameId(R.string.phb);
        }
        else if (DATA.getInstance().factor_value==111){
            setNameId(R.string.u_phb);
        }
    }
    @Override
    public double calculateProportion(Wealth deadPerson, double totalParts) {
        if(deadPerson.countHeirByRelation(SON) != 0){
                setCondition("mahjoob_reason_son");
                return 0;
            }
        if(deadPerson.countHeirByRelation(GRAND_SON) != 0){
                setCondition("mahjoob_reason_grandSon");
                return 0;
            }
        if (deadPerson.getHeir(FATHER) != null) {
            setCondition("mahjoob_reason_father");
            return 0;
        }
        if(deadPerson.countHeirByRelation(REAL_BROTHER) > 0){
            setCondition("mahjoob_reason_fullBrother");
            return 0;
        }
        
        if (deadPerson.countHeirByRelation(REAL_BROTHER)==0 && deadPerson.countHeirByRelation(SON) == 0 && deadPerson.countHeirByRelation(GRAND_SON) == 0
                && deadPerson.getHeir(FATHER) == null && deadPerson.getHeir(PATERNAL_GRAND_FATHER) == null) {
            deadPerson.getAsabaat().add(this);
            setAsaba(true);
            return 0.0;
        }
        
        return 0.0;
    }
    
}
